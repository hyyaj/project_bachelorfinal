// Define study
const study = lab.util.fromObject({
  "title": "root",
  "type": "lab.flow.Sequence",
  "parameters": {},
  "plugins": [
    {
      "type": "lab.plugins.Metadata",
      "path": undefined
    },
    {
      "type": "lab.plugins.Download",
      "filePrefix": "study",
      "path": undefined
    }
  ],
  "metadata": {
    "title": "",
    "description": "",
    "repository": "",
    "contributors": ""
  },
  "files": {},
  "responses": {},
  "content": [
    {
      "type": "lab.flow.Sequence",
      "files": {
        "2a.jpg": "embedded\u002F3da555a0d815725e71d82e9bd447f46e41192b0d610b19eef3960cf64b67fa3b.jpg",
        "2b.jpg": "embedded\u002F211d8af1b51e46dafedb3a63402175262e7183b1fce058ad42cbb49b6bffce7c.jpg"
      },
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Introduction",
      "content": [
        {
          "type": "lab.html.Page",
          "items": [
            {
              "required": true,
              "type": "html",
              "content": "\u003Cheader class=\"content-vertical-center content-horizontal-center\"\u003E\n  \u003Ch1 style=\"white-space: nowrap;\"\u003EFace-Matching Experiment\u003C\u002Fh1\u003E\n\u003C\u002Fheader\u003E\n\u003Cp\u003E\n  Welcome to this face-matching experiment!\n\u003C\u002Fp\u003E\n",
              "name": ""
            }
          ],
          "scrollTop": true,
          "submitButtonText": "Continue →",
          "submitButtonPosition": "right",
          "files": {},
          "responses": {
            "": ""
          },
          "parameters": {},
          "messageHandlers": {},
          "title": "Welcome"
        },
        {
          "type": "lab.html.Page",
          "items": [
            {
              "required": true,
              "type": "html",
              "content": "\u003Csection\u003E\n  \u003Ch2\u003EResearch Information\u003C\u002Fh2\u003E\n  \u003Cp\u003E\n    Thank you for your interest in our research study. We are undergraduate students in the Psychology and Technology program at Eindhoven University of Technology, and this study is part of our final bachelor project.\n  \u003C\u002Fp\u003E\n  \u003Cp\u003E\n    Please read the following information carefully. It explains the purpose of the study, what participation involves, and how your data will be handled.\n  \u003C\u002Fp\u003E\n  \u003Cp\u003E\n    If anything is unclear, feel free to ask us any questions before you continue.\n  \u003C\u002Fp\u003E\n\u003C\u002Fsection\u003E\n",
              "name": ""
            }
          ],
          "scrollTop": true,
          "submitButtonText": "Continue →",
          "submitButtonPosition": "right",
          "files": {},
          "responses": {
            "": ""
          },
          "parameters": {},
          "messageHandlers": {},
          "title": "Research information"
        },
        {
          "type": "lab.html.Page",
          "items": [
            {
              "required": true,
              "type": "html",
              "content": "\u003Csection\u003E\n      \u003Ch2\u003EProcedure\u003C\u002Fh2\u003E\n      \u003Cp\u003EThis study consists of two main components:\u003C\u002Fp\u003E\n      \u003Col\u003E\n        \u003Cli\u003E\u003Cstrong\u003EQuiz\u003C\u002Fstrong\u003E\u003Cbr\u003E\n        First you will complete a small quiz, to test your knowledge of artificial intelligence.\u003C\u002Fli\u003E\u003Cbr\u003E\n        \u003Cli\u003E\u003Cstrong\u003EFace-Matching Task\u003C\u002Fstrong\u003E\u003Cbr\u003E\n       Following the quiz, you will complete 40 trials of a face-matching task, where you will decide whether two faces shown on the screen belong to the same individual or to different individuals.\u003Cbr\u003E\u003Cbr\u003E\n        We will include a practice trial to help you get familiar with the task later！\u003C\u002Fli\u003E\n\n      \u003C\u002Fol\u003E\n    \u003C\u002Fsection\u003E",
              "name": ""
            }
          ],
          "scrollTop": true,
          "submitButtonText": "Continue →",
          "submitButtonPosition": "right",
          "files": {},
          "responses": {
            "": ""
          },
          "parameters": {},
          "messageHandlers": {},
          "title": "Procedure"
        }
      ]
    },
    {
      "type": "lab.html.Page",
      "items": [
        {
          "required": true,
          "type": "html",
          "content": "\u003Ch2\u003EPractice\u003C\u002Fh2\u003E\r\n\u003Cp\u003E Now we will show you a practice trial for you to get familar with the face-matching task!\u003Cp\u003E",
          "name": ""
        }
      ],
      "scrollTop": true,
      "submitButtonText": "Continue →",
      "submitButtonPosition": "right",
      "files": {},
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "practice start page"
    },
    {
      "type": "lab.flow.Loop",
      "templateParameters": [
        {
          "practice_a": "2a.jpg",
          "practice_b": "2b.jpg",
          "practice_ai": "-85.jpg"
        }
      ],
      "sample": {
        "mode": "draw-shuffle"
      },
      "files": {},
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "practice",
      "shuffleGroups": [],
      "template": {
        "type": "lab.flow.Sequence",
        "files": {},
        "responses": {
          "": ""
        },
        "parameters": {},
        "messageHandlers": {},
        "title": "Sequence",
        "content": [
          {
            "type": "lab.html.Page",
            "items": [
              {
                "required": true,
                "type": "html",
                "content": "\u003C!DOCTYPE html\u003E\r\n\u003Chtml lang=\"en\"\u003E\r\n\u003Chead\u003E\r\n  \u003Cmeta charset=\"UTF-8\" \u002F\u003E\r\n  \u003Cmeta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\"\u002F\u003E\r\n  \u003Ctitle\u003EImage Initial Decision\u003C\u002Ftitle\u003E\r\n  \u003Cstyle\u003E\r\n    \u002F* Flexbox container for side-by-side layout *\u002F\r\n    .main-container {\r\n      display: flex;\r\n      align-items: center;\r\n      justify-content: center;\r\n      gap: 40px;\r\n      padding: 30px 0;\r\n    }\r\n    \r\n    \u002F* Styling for the instruction text *\u002F\r\n    .instruction-text {\r\n      text-align: left;\r\n      max-width: 300px; \u002F* Limit the width of the text box *\u002F\r\n    }\r\n    \r\n    \u002F* Button styling *\u002F\r\n    .classification-button {\r\n      font-size: 18px;\r\n      padding: 10px 0;\r\n      text-align: center;\r\n      cursor: pointer;\r\n      border: 2px solid #333;\r\n      background-color: #f8f8f8;\r\n      border-radius: 8px;\r\n      transition: background-color 0.2s ease-in-out, transform 0.1s ease-in-out;\r\n    }\r\n\r\n    .classification-button:hover {\r\n      background-color: #ddd;\r\n    }\r\n\r\n    .classification-button:active {\r\n      background-color: #bbb;\r\n      transform: scale(0.98);\r\n    }\r\n\r\n    \u002F* Flexbox for image container *\u002F\r\n    .image-container {\r\n      display: flex;\r\n      flex-direction: column;\r\n      align-items: center;\r\n      gap: 20px;\r\n    }\r\n  \u003C\u002Fstyle\u003E\r\n\u003C\u002Fhead\u003E\r\n\u003Cbody\u003E\r\n  \u003Cmain class=\"main-container\"\u003E\r\n    \u003C!-- Instruction Text on the left --\u003E\r\n    \u003Cdiv class=\"instruction-text\"\u003E\r\n\u003Ch2\u003EStep 1: Initial Decision\u003C\u002Fh2\u003E\r\n\u003Cp\u003E\r\n  First, you will make an initial decision without any AI advice.\u003Cbr\u003E\u003Cbr\u003E\r\n  Please look at the two faces and decide whether they belong to the same individual or to different individuals.\u003Cbr\u003E\u003Cbr\u003E\r\n  Click \"Same\" or \"Different\" to make your decision!\r\n\u003C\u002Fp\u003E\r\n\r\n\r\n    \u003C\u002Fdiv\u003E\r\n    \r\n    \u003C!-- Image Section on the right --\u003E\r\n    \u003Cdiv class=\"image-container\"\u003E\r\n      \u003Cimg src=\"${ this.files[this.parameters.practice_a] }\" alt=\"Portrait 1\" width=\"180\" height=\"220\"\u003E\r\n      \u003Cimg src=\"${ this.files[this.parameters.practice_b] }\" alt=\"Portrait 2\" width=\"180\" height=\"220\"\u003E\r\n    \u003C\u002Fdiv\u003E\r\n  \u003C\u002Fmain\u003E\r\n\r\n  \u003C!-- Buttons to make selection --\u003E\r\n  \u003Cform\u003E\r\n    \u003Cinput type=\"hidden\" name=\"practice_user_choice\" id=\"userSelection\"\u003E\r\n    \u003Cdiv style=\"display: flex; justify-content: center; gap: 40px; margin-top: 20px;\"\u003E\r\n      \u003Cbutton type=\"submit\" class=\"classification-button\" style=\"width: 180px;\" onclick=\"document.getElementById('userSelection').value='same'\"\u003E\r\n        Same\r\n      \u003C\u002Fbutton\u003E\r\n      \u003Cbutton type=\"submit\" class=\"classification-button\" style=\"width: 180px;\" onclick=\"document.getElementById('userSelection').value='different'\"\u003E\r\n        Different\r\n      \u003C\u002Fbutton\u003E\r\n    \u003C\u002Fdiv\u003E\r\n  \u003C\u002Fform\u003E\r\n\r\n  \u003Cscript\u003E\r\n    const files = this.files;\r\n    const p = this.parameters;\r\n\r\n    const imageA = files[p.image_a]?.url || p.image_a;\r\n    const imageB = files[p.image_b]?.url || p.image_b;\r\n\r\n    const imgTags = document.querySelectorAll('img');\r\n    \r\n    const randomOrder = Math.random() \u003E 0.5;\r\n\r\n    if (randomOrder) {\r\n      imgTags[0].src = imageA;\r\n      imgTags[1].src = imageB;\r\n    } else {\r\n      imgTags[0].src = imageB;\r\n      imgTags[1].src = imageA;\r\n    }\r\n  \u003C\u002Fscript\u003E\r\n\u003C\u002Fbody\u003E\r\n\u003C\u002Fhtml\u003E\r\n",
                "name": ""
              }
            ],
            "scrollTop": true,
            "submitButtonText": "Continue →",
            "submitButtonPosition": "hidden",
            "files": {
              "2a.jpg": "embedded\u002F3da555a0d815725e71d82e9bd447f46e41192b0d610b19eef3960cf64b67fa3b.jpg",
              "2b.jpg": "embedded\u002F211d8af1b51e46dafedb3a63402175262e7183b1fce058ad42cbb49b6bffce7c.jpg"
            },
            "responses": {
              "": ""
            },
            "parameters": {},
            "messageHandlers": {},
            "title": "practice initial decision"
          },
          {
            "type": "lab.html.Page",
            "items": [
              {
                "required": true,
                "type": "text",
                "content": "\u003Cp\u003E\n  In this step, you will rate how confident you feel about your initial decision you just made.\n\u003C\u002Fp\u003E",
                "title": "Step 2: Rating your initial confidence"
              },
              {
                "type": "text",
                "content": "\u003Cp\u003EPlease rate your confidence:\u003C\u002Fp\u003E\n\u003Cp style=\"font-size: 0.9em; color: #555;\"\u003E\n  Use the slider below to indicate how confident you are in your initial choice, where:\n  \u003Cbr\u003E\u003Cstrong\u003E50%\u003C\u002Fstrong\u003E means \"I'm just guessing\", and\n  \u003Cstrong\u003E100%\u003C\u002Fstrong\u003E means \"I'm completely certain.\"\n\u003C\u002Fp\u003E\n\n\u003Cdiv style=\"width: 60%; max-width: 400px;\"\u003E\n  \u003Cinput\n    type=\"range\"\n    id=\"test_initial_confidence_slider\"\n    name=\"test_initial_confidence\"\n    min=\"50\"\n    max=\"100\"\n    value=\"75\"\n    step=\"1\"\n    style=\"width: 100%;\"\n    oninput=\"document.getElementById('slider_value').textContent = this.value;\"\n    required\n  \u003E\n  \u003Cdiv style=\"display: flex; justify-content: space-between; font-size: 0.9em; margin-top: 0.25em;\"\u003E\n    \u003Cspan\u003E50%\u003C\u002Fspan\u003E\n    \u003Cspan\u003E100%\u003C\u002Fspan\u003E\n  \u003C\u002Fdiv\u003E\n  \u003Cp style=\"margin-top: 0.5em;\"\u003ESelected: \u003Cspan id=\"slider_value\"\u003E75\u003C\u002Fspan\u003E%\u003C\u002Fp\u003E\n\u003C\u002Fdiv\u003E\n",
                "title": "Initial confidence"
              }
            ],
            "scrollTop": true,
            "submitButtonText": "Continue →",
            "submitButtonPosition": "right",
            "files": {},
            "responses": {
              "": ""
            },
            "parameters": {},
            "messageHandlers": {},
            "title": "practice initial confidence"
          },
          {
            "type": "lab.html.Page",
            "items": [
              {
                "required": true,
                "type": "html",
                "content": "\u003C!DOCTYPE html\u003E\r\n\u003Chtml lang=\"en\"\u003E\r\n\u003Chead\u003E\r\n  \u003Cmeta charset=\"UTF-8\"\u003E\r\n  \u003Cmeta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\"\u003E\r\n  \u003Ctitle\u003EPractice Image Randomizer\u003C\u002Ftitle\u003E\r\n\u003C\u002Fhead\u003E\r\n\u003Cbody\u003E\r\n  \u003Cmain style=\"display: flex; flex-direction: column; align-items: center; gap: 10px; padding: 30px 0;\"\u003E\r\n\r\n    \u003Ch2\u003EStep 3: Final Decision with AI Advice\u003C\u002Fh2\u003E\r\n\u003Cp\u003E\r\nIn this step, you will see the AI's recommendation based on its analysis of the two faces.\r\n\u003C\u002Fp\u003E\r\n\u003Cp\u003E\r\nThe AI’s confidence is displayed as a vertical bar.\r\nIf the bar \u003Cstrong\u003Eextends upward\u003C\u002Fstrong\u003E, the AI is indicating the faces are the same person.\r\nIf the bar \u003Cstrong\u003Eextends downward\u003C\u002Fstrong\u003E, it is suggesting the faces are from different people.\r\n\u003C\u002Fp\u003E\r\n\u003Cp\u003E\r\nFor example, in this case the AI is \u003Cstrong\u003Eextended upwards\u003C\u002Fstrong\u003E so is suggesting the \u003Cstrong\u003E\"Same\"\u003C\u002Fstrong\u003E with \u003Cstrong\u003E85% confidence\u003C\u002Fstrong\u003E.\r\nThis means the AI believes the two faces show the same person and is 85% certain of this decision.\r\n\u003C\u002Fp\u003E\r\n\r\n\u003Cbr\u003E\r\n    Please make your final decision — you may either confirm or change your initial decision based on the AI’s advice.\r\n    \u003C\u002Fp\u003E\r\n\r\n    \u003C!-- faces and ai_image in a row --\u003E\r\n    \u003Cdiv style=\"display: flex; justify-content: space-between; width: 150%; gap: 350px;\"\u003E\r\n\r\n      \u003C!-- faces in column on the left --\u003E\r\n      \u003Cdiv style=\"display: flex; flex-direction: column; align-items: flex-start; gap: 10px; width: 40%;\"\u003E\r\n        \u003Cimg src=\"${ this.files[this.parameters.practice_a] }\" alt=\"Practice Portrait 1\" width=\"180\" height=\"220\"\u003E\r\n        \u003Cimg src=\"${ this.files[this.parameters.practice_b] }\" alt=\"Practice Portrait 2\" width=\"180\" height=\"220\"\u003E\r\n      \u003C\u002Fdiv\u003E\r\n\r\n      \u003C!-- ai_image on the right --\u003E\r\n      \u003Cdiv style=\"display: flex; justify-content: flex-end; width: 20%;\"\u003E\r\n        \u003Cimg src=\"${ this.files[this.parameters.practice_ai] }\"\r\n             alt=\"AI Decision\"\r\n             style=\"max-width: 400px; width: 250%; height: auto; object-fit: contain;\"\u003E\r\n      \u003C\u002Fdiv\u003E\r\n\r\n    \u003C\u002Fdiv\u003E\r\n\r\n    \u003C!-- buttons --\u003E\r\n    \u003Cform\u003E\r\n      \u003Cinput type=\"hidden\" name=\"practice_user_choice2\" id=\"userSelection\"\u003E\r\n      \u003Cdiv style=\"display: flex; justify-content: center; gap: 40px; margin-top: 20px;\"\u003E\r\n        \u003Cbutton type=\"submit\" class=\"classification-button\" style=\"width: 180px;\" onclick=\"document.getElementById('userSelection').value='same'\"\u003E\r\n          Same\r\n        \u003C\u002Fbutton\u003E\r\n        \u003Cbutton type=\"submit\" class=\"classification-button\" style=\"width: 180px;\" onclick=\"document.getElementById('userSelection').value='different'\"\u003E\r\n          Different\r\n        \u003C\u002Fbutton\u003E\r\n      \u003C\u002Fdiv\u003E\r\n    \u003C\u002Fform\u003E\r\n\r\n  \u003C\u002Fmain\u003E\r\n\r\n  \u003Cstyle\u003E\r\n    .classification-button {\r\n      font-size: 18px;\r\n      padding: 10px 0;\r\n      text-align: center;\r\n      cursor: pointer;\r\n      border: 2px solid #333;\r\n      background-color: #f8f8f8;\r\n      border-radius: 8px;\r\n      transition: background-color 0.2s ease-in-out, transform 0.1s ease-in-out;\r\n    }\r\n\r\n    .classification-button:hover {\r\n      background-color: #ddd;\r\n    }\r\n\r\n    .classification-button:active {\r\n      background-color: #bbb;\r\n      transform: scale(0.98);\r\n    }\r\n  \u003C\u002Fstyle\u003E\r\n\r\n  \u003Cscript\u003E\r\n    \u002F\u002F Function to randomly swap the images\r\n    function randomizeImages() {\r\n      const order = Math.random() \u003E 0.5 ? ['practice_a', 'practice_b'] : ['practice_b', 'practice_a'];\r\n\r\n      const imgA = document.querySelector('img[alt=\"Practice Portrait 1\"]');\r\n      const imgB = document.querySelector('img[alt=\"Practice Portrait 2\"]');\r\n\r\n      imgA.src = this.files[this.parameters[order[0]]];\r\n      imgB.src = this.files[this.parameters[order[1]]];\r\n    }\r\n\r\n    window.onload = randomizeImages;\r\n  \u003C\u002Fscript\u003E\r\n\u003C\u002Fbody\u003E\r\n\u003C\u002Fhtml\u003E\r\n",
                "name": ""
              }
            ],
            "scrollTop": true,
            "submitButtonText": "Continue →",
            "submitButtonPosition": "hidden",
            "files": {
              "2a.jpg": "embedded\u002F3da555a0d815725e71d82e9bd447f46e41192b0d610b19eef3960cf64b67fa3b.jpg",
              "2b.jpg": "embedded\u002F211d8af1b51e46dafedb3a63402175262e7183b1fce058ad42cbb49b6bffce7c.jpg",
              "-85.jpg": "embedded\u002Faee6b2801374ed2ad42c1c27920808144ec759ada464320fc9964d406c4e41b0.jpg"
            },
            "responses": {
              "": ""
            },
            "parameters": {},
            "messageHandlers": {},
            "title": "practice final decision"
          },
          {
            "type": "lab.html.Page",
            "items": [
              {
                "type": "text",
                "content": "\u003Cp\u003EPlease rate your confidence:\u003C\u002Fp\u003E\n\u003Cp style=\"font-size: 0.9em; color: #555;\"\u003E\n  Use the slider below to indicate how confident you are in your in your final choice, where:\n  \u003Cbr\u003E\u003Cstrong\u003E50%\u003C\u002Fstrong\u003E means \"I'm just guessing\", and\n  \u003Cstrong\u003E100%\u003C\u002Fstrong\u003E means \"I'm completely certain.\"\n\u003C\u002Fp\u003E\n\n\u003Cdiv style=\"width: 60%; max-width: 400px;\"\u003E\n  \u003Cinput\n    type=\"range\"\n    id=\"test_final_confidence_slider\"\n    name=\"test_final_confidence\"\n    min=\"50\"\n    max=\"100\"\n    value=\"75\"\n    step=\"1\"\n    style=\"width: 100%;\"\n    oninput=\"document.getElementById('slider_value').textContent = this.value;\"\n    required\n  \u003E\n  \u003Cdiv style=\"display: flex; justify-content: space-between; font-size: 0.9em; margin-top: 0.25em;\"\u003E\n    \u003Cspan\u003E50%\u003C\u002Fspan\u003E\n    \u003Cspan\u003E100%\u003C\u002Fspan\u003E\n  \u003C\u002Fdiv\u003E\n  \u003Cp style=\"margin-top: 0.5em;\"\u003ESelected: \u003Cspan id=\"slider_value\"\u003E75\u003C\u002Fspan\u003E%\u003C\u002Fp\u003E\n\u003C\u002Fdiv\u003E\n\n",
                "title": "Step 4: Rate your final confidence"
              }
            ],
            "scrollTop": true,
            "submitButtonText": "Continue →",
            "submitButtonPosition": "right",
            "files": {},
            "responses": {
              "": ""
            },
            "parameters": {},
            "messageHandlers": {},
            "title": "practice final confidence"
          },
          {
            "type": "lab.html.Page",
            "items": [
              {
                "required": true,
                "type": "html",
                "content": "\r\n  \u003Ch2 style=\"margin-bottom: 10px;\"\u003EPractice Completed!\u003C\u002Fh2\u003E\r\n\u003Cp\u003E\r\n  We believe you are now familiar with the full procedure. \u003Cbr\u003E\r\n\u003C\u002Fp\u003E\r\n\r\n\u003Cp\u003E\r\n  Click “Continue” to start the experiment!  \u003Cbr\u003E\r\n\u003C\u002Fp\u003E\r\n",
                "name": ""
              }
            ],
            "scrollTop": true,
            "submitButtonText": "Continue→",
            "submitButtonPosition": "right",
            "files": {},
            "responses": {
              "": ""
            },
            "parameters": {},
            "messageHandlers": {},
            "title": "practice complete"
          },
          {
            "type": "lab.canvas.Screen",
            "content": [],
            "viewport": [
              800,
              600
            ],
            "files": {},
            "responses": {
              "": ""
            },
            "parameters": {},
            "messageHandlers": {},
            "title": "practice Inter trial interval",
            "timeout": "500"
          }
        ]
      }
    },
    {
      "type": "lab.flow.Loop",
      "templateParameters": [
        {
          "image_a": "9a.jpg",
          "image_b": "9b.jpg",
          "true_value": "true",
          "ai_image": "75.jpg"
        },
        {
          "image_a": "10a.jpg",
          "image_b": "10b.jpg",
          "true_value": "true",
          "ai_image": "-80.jpg"
        },
        {
          "image_a": "15a.jpg",
          "image_b": "15b.jpg",
          "true_value": "true",
          "ai_image": "-95.jpg"
        },
        {
          "image_a": "20a.jpg",
          "image_b": "20b.jpg",
          "true_value": "true",
          "ai_image": "-85.jpg"
        },
        {
          "image_a": "21a.jpg",
          "image_b": "21b.jpg",
          "true_value": "true",
          "ai_image": "-85.jpg"
        },
        {
          "image_a": "23a.jpg",
          "image_b": "23b.jpg",
          "true_value": "true",
          "ai_image": "90.jpg"
        },
        {
          "image_a": "25a.jpg",
          "image_b": "25b.jpg",
          "true_value": "true",
          "ai_image": "-60.jpg"
        },
        {
          "image_a": "29a.jpg",
          "image_b": "29b.jpg",
          "true_value": "true",
          "ai_image": "65.jpg"
        },
        {
          "image_a": "31a.jpg",
          "image_b": "31b.jpg",
          "true_value": "true",
          "ai_image": "-65.jpg"
        },
        {
          "image_a": "32a.jpg",
          "image_b": "32b.jpg",
          "true_value": "true",
          "ai_image": "-95.jpg"
        },
        {
          "image_a": "37a.jpg",
          "image_b": "37b.jpg",
          "true_value": "true",
          "ai_image": "90.jpg"
        },
        {
          "image_a": "38a.jpg",
          "image_b": "38b.jpg",
          "true_value": "true",
          "ai_image": "55.jpg"
        },
        {
          "image_a": "47a.jpg",
          "image_b": "47b.jpg",
          "true_value": "true",
          "ai_image": "-55.jpg"
        },
        {
          "image_a": "48a.jpg",
          "image_b": "48b.jpg",
          "true_value": "true",
          "ai_image": "-70.jpg"
        },
        {
          "image_a": "51a.jpg",
          "image_b": "51b.jpg",
          "true_value": "true",
          "ai_image": "-60.jpg"
        },
        {
          "image_a": "57a.jpg",
          "image_b": "57b.jpg",
          "true_value": "true",
          "ai_image": "-70.jpg"
        },
        {
          "image_a": "59a.jpg",
          "image_b": "59b.jpg",
          "true_value": "true",
          "ai_image": "65.jpg"
        },
        {
          "image_a": "60a.jpg",
          "image_b": "60b.jpg",
          "true_value": "true",
          "ai_image": "-80.jpg"
        },
        {
          "image_a": "63a.jpg",
          "image_b": "63b.jpg",
          "true_value": "true",
          "ai_image": "-65.jpg"
        },
        {
          "image_a": "70a.jpg",
          "image_b": "70b.jpg",
          "true_value": "true",
          "ai_image": "-75.jpg"
        },
        {
          "image_a": "78a.jpg",
          "image_b": "78b.jpg",
          "true_value": "false",
          "ai_image": "-90.jpg"
        },
        {
          "image_a": "81a.jpg",
          "image_b": "81b.jpg",
          "true_value": "false",
          "ai_image": "65.jpg"
        },
        {
          "image_a": "84a.jpg",
          "image_b": "84b.jpg",
          "true_value": "false",
          "ai_image": "80.jpg"
        },
        {
          "image_a": "86a.jpg",
          "image_b": "86b.jpg",
          "true_value": "false",
          "ai_image": "70.jpg"
        },
        {
          "image_a": "83a.jpg",
          "image_b": "83b.jpg",
          "true_value": "false",
          "ai_image": "-80.jpg"
        },
        {
          "image_a": "95a.jpg",
          "image_b": "95b.jpg",
          "true_value": "false",
          "ai_image": "-65.jpg"
        },
        {
          "image_a": "98a.jpg",
          "image_b": "98b.jpg",
          "true_value": "false",
          "ai_image": "65.jpg"
        },
        {
          "image_a": "105a.jpg",
          "image_b": "105b.jpg",
          "true_value": "false",
          "ai_image": "95.jpg"
        },
        {
          "image_a": "112a.jpg",
          "image_b": "112b.jpg",
          "true_value": "false",
          "ai_image": "55.jpg"
        },
        {
          "image_a": "113a.jpg",
          "image_b": "113b.jpg",
          "true_value": "false",
          "ai_image": "-60.jpg"
        },
        {
          "image_a": "116a.jpg",
          "image_b": "116b.jpg",
          "true_value": "false",
          "ai_image": "75.jpg"
        },
        {
          "image_a": "118a.jpg",
          "image_b": "118b.jpg",
          "true_value": "false",
          "ai_image": "95.jpg"
        },
        {
          "image_a": "119a.jpg",
          "image_b": "119b.jpg",
          "true_value": "false",
          "ai_image": "70.jpg"
        },
        {
          "image_a": "120a.jpg",
          "image_b": "120b.jpg",
          "true_value": "false",
          "ai_image": "-60.jpg"
        },
        {
          "image_a": "123a.jpg",
          "image_b": "123b.jpg",
          "true_value": "false",
          "ai_image": "-85.jpg"
        },
        {
          "image_a": "125a.jpg",
          "image_b": "125b.jpg",
          "true_value": "false",
          "ai_image": "90.jpg"
        },
        {
          "image_a": "126a.jpg",
          "image_b": "126b.jpg",
          "true_value": "false",
          "ai_image": "65.jpg"
        },
        {
          "image_a": "132a.jpg",
          "image_b": "132b.jpg",
          "true_value": "false",
          "ai_image": "75.jpg"
        },
        {
          "image_a": "134a.jpg",
          "image_b": "134b.jpg",
          "true_value": "false",
          "ai_image": "85.jpg"
        },
        {
          "image_a": "136a.jpg",
          "image_b": "136b.jpg",
          "true_value": "false",
          "ai_image": "55.jpg"
        }
      ],
      "sample": {
        "mode": "draw-shuffle",
        "n": ""
      },
      "files": {},
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Pilot study stimuli",
      "shuffleGroups": [],
      "template": {
        "type": "lab.flow.Sequence",
        "files": {},
        "responses": {
          "": ""
        },
        "parameters": {},
        "messageHandlers": {},
        "title": "Sequence",
        "content": [
          {
            "type": "lab.html.Page",
            "items": [
              {
                "required": true,
                "type": "html",
                "content": "\u003C!DOCTYPE html\u003E \r\n\u003Chtml lang=\"en\"\u003E \r\n\u003Chead\u003E \r\n\u003Cmeta charset=\"UTF-8\" \u002F\u003E \r\n\u003Cmeta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\"\u002F\u003E \r\n\u003Ctitle\u003EImage Initial Decision\u003C\u002Ftitle\u003E \r\n\u003C\u002Fhead\u003E \r\n\u003Cbody\u003E \r\n\u003Cmain style=\"display: flex; flex-direction: column; align-items: center; gap: 5px; padding: 30px 0;\"\u003E \r\n\u003C!-- face --\u003E \r\n\u003Cdiv style=\"display: flex; flex-direction: column; align-items: center; gap: 20px;\"\u003E \r\n\u003Cimg src=\"${ this.files[this.parameters.image_a] }\" alt=\"Portrait 1\" width=\"180\" height=\"220\"\u003E \r\n\u003Cimg src=\"${ this.files[this.parameters.image_b] }\" alt=\"Portrait 2\" width=\"180\" height=\"220\"\u003E \r\n\u003C\u002Fdiv\u003E \r\n\u003C!-- buttons --\u003E \r\n\u003Cform\u003E \r\n\u003Cinput type=\"hidden\" name=\"initial_decision\" id=\"userSelection\"\u003E \r\n\u003Cdiv style=\"display: flex; justify-content: center; gap: 40px; margin-top: 20px;\"\u003E \r\n\u003Cbutton type=\"submit\" class=\"classification-button\" style=\"width: 180px;\" onclick=\"document.getElementById('userSelection').value='same'\"\u003E \r\nSame \r\n\u003C\u002Fbutton\u003E \r\n\u003Cbutton type=\"submit\" class=\"classification-button\" style=\"width: 180px;\" onclick=\"document.getElementById('userSelection').value='different'\"\u003E \r\nDifferent \r\n\u003C\u002Fbutton\u003E \r\n\u003C\u002Fdiv\u003E \r\n\u003C\u002Fform\u003E \r\n\u003C\u002Fmain\u003E \r\n\u003Cstyle\u003E \r\n.classification-button { \r\nfont-size: 18px; \r\npadding: 10px 0; \r\ntext-align: center; \r\ncursor: pointer; \r\nborder: 2px solid #333; \r\nbackground-color: #f8f8f8; \r\nborder-radius: 8px; \r\ntransition: background-color 0.2s ease-in-out, transform 0.1s ease-in-out; \r\n} \r\n.classification-button:hover { \r\nbackground-color: #ddd; \r\n} \r\n.classification-button:active { \r\nbackground-color: #bbb; \r\ntransform: scale(0.98); \r\n} \r\n\u003C\u002Fstyle\u003E \r\n\u003Cscript\u003E \r\nconst files = this.files; \r\nconst p = this.parameters; \r\n\r\nconst imageA = files[p.image_a]?.url || p.image_a; \r\nconst imageB = files[p.image_b]?.url || p.image_b; \r\n\r\nconst imgTags = document.querySelectorAll('img'); \r\n \r\nconst randomOrder = Math.random() \u003E 0.5; \r\n\r\nif (randomOrder) { \r\nimgTags[0].src = imageA; \r\nimgTags[1].src = imageB; \r\n} else { \r\nimgTags[0].src = imageB; \r\nimgTags[1].src = imageA; \r\n} \r\n\r\n\u003C\u002Fscript\u003E \r\n\u003C\u002Fbody\u003E \r\n\u003C\u002Fhtml\u003E\r\n\r\n",
                "name": ""
              }
            ],
            "scrollTop": true,
            "submitButtonText": "Continue →",
            "submitButtonPosition": "hidden",
            "files": {
              "140b.jpg": "embedded\u002Fdcccd663d5af1da58a1375acac0fd2386604b75eeb655d1cc8f25fb92a697133.jpg",
              "140a.jpg": "embedded\u002F26ae622b6033f7d96917e75ec106d606e0cd4f8e4543919a66c637b52f34d76b.jpg",
              "139b.jpg": "embedded\u002F092d705859deac34f64abd5d08cd6ff8235a2af3f4a65be0ef908d9a2b40c7c6.jpg",
              "139a.jpg": "embedded\u002Fac69da592d2229c081572cee0dcea00cf794b802677d6765be7ff5b1161d89ec.jpg",
              "138b.jpg": "embedded\u002F7e84295f28860ac905186ca0ec20bbb6a0267414af8188e53d00907c34594400.jpg",
              "138a.jpg": "embedded\u002F26e1bd71230ea0777d3526fa27e031e8847ca25d2e1a3298b6ed3794e76fc5cf.jpg",
              "137b.jpg": "embedded\u002F77c866aa15472376190495140c84ac69bc87d6df028f856adc4af674908cad8d.jpg",
              "137a.jpg": "embedded\u002F52e5d115f5474eba7230fc7a83550383655b45de2e960e926e0feaad05ae6984.jpg",
              "136b.jpg": "embedded\u002F59e8e48977f0f988abf68beba79a137797e86faa622aa9114f9fd728a25190e7.jpg",
              "136a.jpg": "embedded\u002F3892f7276471bfe7cb60b6ce49c816f76c182d8b199337477c7c494f74b8cc20.jpg",
              "135b.jpg": "embedded\u002F0b5d56393044b8e89ad4552866da284c9f0114ba33cd5c7db66067cc5600e4ad.jpg",
              "135a.jpg": "embedded\u002F66577454e29e20fa4aaad672427920541759c3fb53236ec4a37e802b7e418f2a.jpg",
              "134b.jpg": "embedded\u002F0ba3b23e7f8442fc4788d9408dae0e53359ff99756e2d328813577e8956ca635.jpg",
              "134a.jpg": "embedded\u002F3954e7151dcd21d2db1c6d81186ac90cb1ce54f8749e9e2612f26f463beeb0db.jpg",
              "133b.jpg": "embedded\u002F59b52c324905bc9a441567b6b00d2629113ef6d8ae598c635d29cd7842fe7c95.jpg",
              "133a.jpg": "embedded\u002Fbd66c9515e0e0edad8ac585dab9999dc2ade751acf7de036e95bebddf227dafc.jpg",
              "132b.jpg": "embedded\u002Ffe4bc12413c692e078767ff6d53932ee4bb391c47ff5ee1095e155d119361896.jpg",
              "132a.jpg": "embedded\u002F3fbb547607814fb14bedccab40290df125a1282403a157f64cb4923756004cee.jpg",
              "131b.jpg": "embedded\u002F29259c20f87338e69f904cb858876b7a428faea1fae3af51214ced1170e4abc8.jpg",
              "131a.jpg": "embedded\u002F088e2be9bd8c228f7a33d8f56fbb7bdc2ec0adb73bb313268fd618e446c31ef6.jpg",
              "130b.jpg": "embedded\u002Fc92d23d58942e28ec555455a6df2ceb6d7915d55ef923834d7c4454508ef1071.jpg",
              "130a.jpg": "embedded\u002Fbf7bdcb961b8e6adb0a7691c4416c4011db9c26bc697f8cdb56d27ee896476f8.jpg",
              "129b.jpg": "embedded\u002F5795d5df29ff31d836e38810f6ab8406c5167d058747974d91a326ffafb7da97.jpg",
              "129a.jpg": "embedded\u002F6df0b8622c53c440a9d607f530ddff6dbff50dd0534bf24b22f4b0eb09c79607.jpg",
              "128b.jpg": "embedded\u002Fbb20840e6e0dbbbe916e1789e76b03836c94921864a23affedce3404f6895a59.jpg",
              "128a.jpg": "embedded\u002Fd9705e9ceb3042b58b44976e076364a7ad0bb1c268bca5be266626437fc84acb.jpg",
              "127b.jpg": "embedded\u002Fb7039bfcad848ff1e9cb62aeda97bcb8718ce69efeabecb545867e98c6660465.jpg",
              "127a.jpg": "embedded\u002Ff9345bb52da83f9c91db7641becebd304950bf8691f4bd80c77c624f3c8958fc.jpg",
              "126b.jpg": "embedded\u002F7ad5cdf60bf524c40fccf9eac2043d11eaf24b4a39c0ed8734563aec0fa15515.jpg",
              "126a.jpg": "embedded\u002Faf806ce0a0c326747104d2c1c85da7502c9d46c7f1bedb19cdae5e36db844f3f.jpg",
              "125b.jpg": "embedded\u002F1ffa8e4470ff1a078b723883e1ca59f1c2b709baefaaef5f3e0b724213caa730.jpg",
              "125a.jpg": "embedded\u002F243e43c7b8702e99ace48337bdb7341172560d3f28f6657abe79d7bc006aa926.jpg",
              "124b.jpg": "embedded\u002F25b4988292cb2f46e4a4b4d7e44223b3da7274dad9a6b999e41a5de84a4ac264.jpg",
              "124a.jpg": "embedded\u002F4c9dcae1a3ea253417d7a17a0d3b5c48d2a244f34c984d8588ff21e4738f5c47.jpg",
              "123b.jpg": "embedded\u002Fc0786d9028f7d195e2a3009f369545decd0aa872be089f9a320fa1adfd0587b4.jpg",
              "123a.jpg": "embedded\u002F6ee8ccb9ff758f221c2732ab497cbfb8bf8a28616b4a883e449a9be50b55d96c.jpg",
              "122b.jpg": "embedded\u002Fd9a20991436a599457b2a6b8a3da2031bb68bc8c0b19bb8320a1790b4cf4d6b4.jpg",
              "122a.jpg": "embedded\u002F33bcfbd87f53cfd0d8646ef1e17d794fa163e54f3bdfcb5e4452a24ce7426edc.jpg",
              "121b.jpg": "embedded\u002F3751368659ca5d441dae58c6a3dd436a4242bbd23a2fc10ac8af6f2b4d60e78a.jpg",
              "121a.jpg": "embedded\u002Fb5fc03ab8f41ce797c928dd908340da0b62c6c9c4b1ac760327544e932f7ae17.jpg",
              "120b.jpg": "embedded\u002F70ed906f796fb7e42c6bf28a6b48f798a9df16be40bfdc8931f4ee1854b8c663.jpg",
              "120a.jpg": "embedded\u002F1bcbaf8f440c1710f50af7d4ede81f2fabcfa04c8850087b91ad039b8a52c8f4.jpg",
              "119b.jpg": "embedded\u002F84f6977ee319392479f28ffa07f2c18a40c7cecf3d41aad84697b5358097856f.jpg",
              "119a.jpg": "embedded\u002F430b5b114e0469901b7c5c63b9d9e4eed37701928ae3f4d6bc362894ffb7deb2.jpg",
              "118b.jpg": "embedded\u002F9feac0be667a2718ee58207c16125c7da5bd628f4ec94c61ec249876510e9df4.jpg",
              "118a.jpg": "embedded\u002F65714fb6e858edfe228fef89848201acc3d1b1b594a23791b09d146d259b742e.jpg",
              "117b.jpg": "embedded\u002F1a7f733484fd56fceb8c1531c59a3262c42eba0bf034da90d2ccb2dbfa1aa4c0.jpg",
              "117a.jpg": "embedded\u002F308e877ba9f63f8734e6ba45849bff34129a7659e1b54a90a8ea2de8c281879a.jpg",
              "116b.jpg": "embedded\u002F56536b49a971a0a1cea02ac14bc648c35505c2bb86aafe69436525802d17408e.jpg",
              "116a.jpg": "embedded\u002F337319549c90ba1d35d4441cca9c6ab903d10db7f39dc331a67e458e24de0a99.jpg",
              "115b.jpg": "embedded\u002F83168bcec95c2eae0d1d523ae1668a96e9d2e1ff24b489b5d3e11c60e62aabb7.jpg",
              "115a.jpg": "embedded\u002F35e9c207a0d8e29179d7c6c2c0497405c4807b85fff9c331f2f9c5ba6dc22d24.jpg",
              "114b.jpg": "embedded\u002F18d3c6bbabc85f406a936d4059f04768d478933c96ee9b4806ef60d69b9db618.jpg",
              "114a.jpg": "embedded\u002Fe87866b83ad3c770eebb47c7fd9debf236496c7bc72f320a43b0be8a84716df5.jpg",
              "113b.jpg": "embedded\u002F0116ca98ee2edbcae4c0229e4677c88494df9ad0e99aff3cb7bbe9fd7d952a42.jpg",
              "113a.jpg": "embedded\u002F429c2a5f02dd6bca04447de85c5d981e23cd747125330cb64ad04bf7804c6264.jpg",
              "112b.jpg": "embedded\u002Fa1efe8c8a9967e8dd7668afcf7c892c2ec4610e6ae61781be4900d88e96ede74.jpg",
              "112a.jpg": "embedded\u002Ff5d434effa2263eb7cffe6c5af2678f646a13a660bd80b3ce3985ab1f030f81d.jpg",
              "111b.jpg": "embedded\u002Fff131609c3b1b7696a6c5ff364845fb67f82f0301254bc33c1328c4b3119ef95.jpg",
              "111a.jpg": "embedded\u002Fc22a550045de72d117c0679c99d422cd9998b372f819b71e4b505c5f795675fb.jpg",
              "110b.jpg": "embedded\u002Fae2a5a5e4a62f3f7d4717576efec87b9369c140b912cd1042170f23084e861e0.jpg",
              "110a.jpg": "embedded\u002F85e24f289e269a25b41254d5fb5b732dd11b5b187ac6efca9dbd1bff9ab7be0b.jpg",
              "109b.jpg": "embedded\u002F105368e75cdcd5cafc108523d1b5bbc18f9f02c15e505f8284d554b384e80119.jpg",
              "109a.jpg": "embedded\u002Fc4b1b523ed900ac5574cc16441ada2e916f511b84bf41e591a925415065c2ada.jpg",
              "108b.jpg": "embedded\u002F2d01064cb90a1a112030e42e5a6801b594d25b8949f971869f4aa8b24d072fa6.jpg",
              "108a.jpg": "embedded\u002F2a1dfa634d0bad4b1629e3d78b8db6fdb0d266594d237f1bcf11b53c8550e3a2.jpg",
              "107b.jpg": "embedded\u002Faec4ec4ee09b6c66ba7bb0326707e6a8747ce1717243d1f13e84c4644dbbd3ba.jpg",
              "107a.jpg": "embedded\u002Fee953deab1177e2d8021e223be1cbd9a89870a5baf7fe247d9e5806da79b86ba.jpg",
              "106b.jpg": "embedded\u002Fa339be7cc6960dcd14b47362ed8ae65fe2e6ff280c971d6344dbae4fa539058d.jpg",
              "106a.jpg": "embedded\u002Fb44f1254a8ff29f69c2af85b4148920c7cd7f135d763a1bfa45b7f60e0030be0.jpg",
              "97b.jpg": "embedded\u002Fe316d92706db3aa9bba1fbff3b1d08f95ce32d117b6c4bdab59907d887e5743f.jpg",
              "93a.jpg": "embedded\u002Fdba32cb6a231f1512888156d561f6f28061ffb07a92bd6e72d97b419137aa98c.jpg",
              "93b.jpg": "embedded\u002Fdb1600f9d48af877ad1efdd9579846200f68bdcc1895658ae8bbac0803f28508.jpg",
              "94a.jpg": "embedded\u002Fabc8f84e11fd1c6ad9c6a1f9525761abb800d2780a479b12e89f0780f862ff07.jpg",
              "96a.jpg": "embedded\u002F6e12ab22a36616cb9dd9f824adf54b644657bfe2d27bf0ac654bd9c15de4a9a4.jpg",
              "96b.jpg": "embedded\u002F1834b0d790e0da9ddd6158884cc96e0f0d4715a9d8def0a6360dbaaedd9e62d9.jpg",
              "97a.jpg": "embedded\u002Ff9394b86dfe33347cb5b3271c6b97d01a3b462ed286f8d6fff8b87e9aa6a47c5.jpg",
              "98a.jpg": "embedded\u002F1eca0ebfc9b7c40b045491fcca9fedd96bbfd9815c7cadac5a82e14035a84df7.jpg",
              "98b.jpg": "embedded\u002F9c8a7d510e9d7cb6ab5b1f24dca9b5596aaa60c57f75be940c91c3dce4fba1a6.jpg",
              "99a.jpg": "embedded\u002F367f1a9187c18ce419c2876b2f0b28de6c48a7d7522e55c28065772f00f474b4.jpg",
              "99b.jpg": "embedded\u002F54b12658b9cd5635dd68a0a80cba44175472dfbd6c3a93f06a35ac875f353037.jpg",
              "91b.jpg": "embedded\u002F201b932c4b6282c18d44241dbfe43fa83a1543440527d633f8cdcfdd147eb615.jpg",
              "92a.jpg": "embedded\u002F6f975ec948f1040e934fcf5bbe267249b32b24d17db6538462be83c3ddb8d193.jpg",
              "92b.jpg": "embedded\u002Fb20e59de6cc6573d3b01e7566f3c8e82178c6f673e6fd98a3f2d4106a8910f2b.jpg",
              "94b.jpg": "embedded\u002Fa3718704c8749ada4155d6997907108e18f68ea909435033865cc6cd86106fa0.jpg",
              "95a.jpg": "embedded\u002Fd6683f1527ad34133abe922f41344d6e5c0ff9d3db8cb76dee26b0f55d9359de.jpg",
              "95b.jpg": "embedded\u002F4278f19008e725d7db6142b040cc93ffe52cd48793638792613a29461fd0c638.jpg",
              "83b.jpg": "embedded\u002Fe57d20baca9c1a30f6366e7cbeabc47283c3e9759b7960be625fb7d856a199b6.jpg",
              "87a.jpg": "embedded\u002F144841285192d9876edd57ce4e2412e5370b3a10c78d9235b8d7e5e8acbddaf7.jpg",
              "87b.jpg": "embedded\u002Ff558f7a5c760340b1ef61c605cc9c74f5be134fe78674e9e932466bb6146834c.jpg",
              "88a.jpg": "embedded\u002Fe036a396aa602741fe4057f8f68814a9781932d2fe3717f241ef5da0cb1eb326.jpg",
              "88b.jpg": "embedded\u002F3101e2a7567e88a0894d83b1fd0fb400f6f76ecce2612371f6f1964015a983d1.jpg",
              "89a.jpg": "embedded\u002Fd7e384ceaeb0341bc1d6b1b29f5a63c38f040e670b68e59d635264c6346f4ba5.jpg",
              "89b.jpg": "embedded\u002Fae9373f3a6e6a0db4049ffa83a8a3f0211a2e7fad1a7e146aa85f6a67d902276.jpg",
              "90a.jpg": "embedded\u002Ff8e96c18efc5ebf895373294122060decf3520179173362b597ed0d032fcb882.jpg",
              "90b.jpg": "embedded\u002Ff361ecc670b422b5d0f6d7751c750c99ad74198a524c463accf42af88c60f7c0.jpg",
              "91a.jpg": "embedded\u002F032c47b3baad163ab3e34b7551337f98e1d6a2b3f13f60bb7f173a36a825afe0.jpg",
              "81b.jpg": "embedded\u002F0d712dd613cfc80490711f20a65f3631fbd843b6bf495457cb3805c9ad298e7b.jpg",
              "82a.jpg": "embedded\u002F49b62c580d6058d127abf138f32cc9d285c1dbb2ff9918f2611d9b79c9396f8a.jpg",
              "82b.jpg": "embedded\u002F734dab6e44a9d664e825793b5956bc6e1f2ad16d0238f99a9d2b4c3401234b5e.jpg",
              "83a.jpg": "embedded\u002F94317c10c2f3937d80e8b5078067b7eda3e4363ff5e518d3cf4cddbacb49c091.jpg",
              "84a.jpg": "embedded\u002Fd449825f24f2ff137205d5c1dbbd218d5dca4b5f758ba6c13c7a5dae7fd08bbc.jpg",
              "84b.jpg": "embedded\u002F9a3b858e9cd8cadde1ad77f9dccbb5083aa904e27ec2be42a746f23a28970340.jpg",
              "85a.jpg": "embedded\u002F1e358c7cb0ee960dcd36e73225f2824f897633744c3bf3638140aac4dd45d01e.jpg",
              "85b.jpg": "embedded\u002Fbc7ffba03684f3a522e4e09caffeef4578dc77d6ea1e88848c984b7cffa6ca0d.jpg",
              "86a.jpg": "embedded\u002F5397d82663c46854ef110b13cfd712b78efbabef78dad43bc0cfb5cf31dec7f5.jpg",
              "86b.jpg": "embedded\u002F79035d4ced825e989cfb25813db379252de71136ebef5c5d608650b6fa5702c6.jpg",
              "77a.jpg": "embedded\u002Fe71b09de8a21851bd623c44b6b91a6cacff872d32197f786cb1f6dda645999c6.jpg",
              "77b.jpg": "embedded\u002F2bc322194fb475e0b1a9d094377e19b2d9d117ec80669d9e305ba7c90d8dc0a2.jpg",
              "78a.jpg": "embedded\u002F7c01eabb5599883493c1b47d34b9284e7a9bde126890d10bc8abf4b1eb1143bc.jpg",
              "78b.jpg": "embedded\u002F1e69c131480ea3ad38135e77e2862e0c9da62571f7bfc7ddac5a9374a1a06f79.jpg",
              "79a.jpg": "embedded\u002F8908ccda60a95d6b7d1ea52e50a875b4a22057dcd1007de202b1067afdbdebb8.jpg",
              "79b.jpg": "embedded\u002Fce9527ded1121add298e72857b63d2851dfdf963e31fa8e03156890abac77507.jpg",
              "80a.jpg": "embedded\u002F4a7bef7f37d4afaacde95a44ebd12564a31d4241cfc93f1b5d2a2786935e562f.jpg",
              "80b.jpg": "embedded\u002Fac44e2f44b72de34a2d6816fcb2bb4c0469cb3cb5c331a11a6280dd2e6cc55bd.jpg",
              "81a.jpg": "embedded\u002Fc5b8e05becab6bb12ddf24ca56d2936617b6e16d2086d1555e4e2299a267a8fe.jpg",
              "71a.jpg": "embedded\u002Fbf7bdcb961b8e6adb0a7691c4416c4011db9c26bc697f8cdb56d27ee896476f8.jpg",
              "71b.jpg": "embedded\u002F6a4dae583952f22555c701d2763c557f6b64f86d8b5275d315cc8922d2d63cd4.jpg",
              "72a.jpg": "embedded\u002Ffaa76474efd29122c5dde32d522fec2a7b199e8775d438118217c0d6931de635.jpg",
              "72b.jpg": "embedded\u002Fb02bde6b1a0d4a7dc1444a58521ff091eb333acd7a93bc7cc7e592f0e246eede.jpg",
              "73a.jpg": "embedded\u002Fe8aca2141e3548b4f70caef51baf51671955db8af48fdfb78d6fc32a79a15908.jpg",
              "73b.jpg": "embedded\u002F82059c128f7a4ae11157f320ef2d5a674ddd4c015d0670be562728999b878862.jpg",
              "74a.jpg": "embedded\u002F6f244faaafcdde0dce0b30b3ff29c09e86659e60ef548960e81e2d59830c47e4.jpg",
              "74b.jpg": "embedded\u002F4035278160613027c81b0f5ba5473d9fea179efa79c06cfac308dda0fabb6a4e.jpg",
              "75a.jpg": "embedded\u002Fdcdd8807c6088731fb506ebf9288833d849a512aff726dc4e2fd8eef1921eb4c.jpg",
              "75b.jpg": "embedded\u002F83b1b495175ba0d46578e169487c0ef51d9981fb07c9cc033af47a7b9b5b628e.jpg",
              "76a.jpg": "embedded\u002Ffb93a9867e43221636bb692e96f9ee0c8783a3ff279f62e8c0742a79139286f7.jpg",
              "76b.jpg": "embedded\u002Fd5dfc09396a5d56a5974647d3149ffab1c6b2a235e7694245cece22bd04787c9.jpg",
              "101b.jpg": "embedded\u002F410a98bf40a1c7e9922d4298014dc98819f4e9e24e5d9a55eb55d1e46c2df224.jpg",
              "102a.jpg": "embedded\u002Fb41d0418853893e19249a3e3b5beda11aa98b71c6c8512781b69e341204dba76.jpg",
              "102b.jpg": "embedded\u002F1d8a1d60aee74eed77f96467c31185b734413a0290588627432b0ff9fce4806c.jpg",
              "103a.jpg": "embedded\u002F062ef954e83a669323deefa16c29444605a2f8ba755e24e088c8d8901a548171.jpg",
              "103b.jpg": "embedded\u002F3cac238b501270b62f8e82f116db2fd6e211363ca8c674b09dbcc3a25ce75ce6.jpg",
              "104a.jpg": "embedded\u002F66b9201a030fdbd01ad93a2ced03f3b88203f2d5b312b38fa20afeaf50c98563.jpg",
              "104b.jpg": "embedded\u002F9c96cb2c0a5a70999c0e8d999b8ccd6e3c4fa8eb2300e0d95cdda2106d0eb342.jpg",
              "105a.jpg": "embedded\u002Fec770d3fa188f73a05f121c4b6c5da9343728a837e3b4c65988e602a98220b6b.jpg",
              "105b.jpg": "embedded\u002Ff2effa9f9e20d17f554a877a0f9de81d30dc00270e43024af88ff9f64fc990db.jpg",
              "100a.jpg": "embedded\u002Fe0191c5be0b791a16163d06631cb183dee82a1ac65293894823d8e81269cf106.jpg",
              "100b.jpg": "embedded\u002Ff1515aca03b964598d410d24cdd5a021f1b2384328ae29b2b4c68751574ed433.jpg",
              "101a.jpg": "embedded\u002F21ea4ed2fad595900c5ddd3d4c9e7634d5e69cb1fe6e58ece5e5fc2796a3fd02.jpg",
              "6a.jpg": "embedded\u002F307361b91818a3930d5d665bb1c1f0ecda01e41f6fd7ff43ba881f4550510189.jpg",
              "6b.jpg": "embedded\u002F76acc9ef36559c83e5fa8459ad2099406d10d9d7d0e8e62d8745c7dade3240c2.jpg",
              "7a.jpg": "embedded\u002F24d26b29e346072699b666243eb21d790a784a3daa111051794503dc4c80c9fc.jpg",
              "7b.jpg": "embedded\u002Fae55cebe61757e1fed62d635b1ba35cb800fe1f2d17999e48fd8c9f94cafc2b1.jpg",
              "8a.jpg": "embedded\u002F08c65ad52ecd235f517c83be67013c4bfc7bd083fe9289c2d3ca6cebdc55a2ed.jpg",
              "8b.jpg": "embedded\u002F4642a046e3d18a01e09d7b47deae3ad1bf2708b8076cf6ea72bb78641e5ca95e.jpg",
              "9a.jpg": "embedded\u002F9cb020191f70dc62ae4f8388f4d5960289ce30d534214649f2c28ad1a896f92a.jpg",
              "9b.jpg": "embedded\u002Fabaa6047f963657dec15dc122a317e43be0e91342df56d8fef53525508dbfc27.jpg",
              "69b.jpg": "embedded\u002F49537727a8a861872bb0625e6253eec46d43792b07ba9c0efd8e500b9636a73f.jpg",
              "70a.jpg": "embedded\u002Feb1d49cca13608a4f11236240732f26f2b7082e155a8209f04e7a36785d1c7a6.jpg",
              "70b.jpg": "embedded\u002F0696ba1526798f0375f3ed4b3bb20b699b6b285747b04a3d7ce6577358ef1d50.jpg",
              "61a.jpg": "embedded\u002Fb053347117017bc175ae3bfd5d8296f8f86b0eed127378b047355c5db67fa328.jpg",
              "64a.jpg": "embedded\u002Fa7f4cee8e20606f1ba04284afb9e383d932ee7cac02cc54c7e867c2289a0c3c5.jpg",
              "64b.jpg": "embedded\u002F6029698fc0022e12d8aecbc11b002796b1822579168a608a1f9b26266ee21a41.jpg",
              "65a.jpg": "embedded\u002Fc8427a2c3556e180f14d7c4232ad49f479e859aa52326bcc9a1e8d666ddc5c09.jpg",
              "65b.jpg": "embedded\u002F23e2dc129339fc8ca55d6d8b039d4d3ec44f3fa4534e1628b45a6e18cc58c4b8.jpg",
              "66a.jpg": "embedded\u002Fb49b98842fa4ee9efc18f4570d942f374310c3ca500431396b166fcf95f5db75.jpg",
              "66b.jpg": "embedded\u002F90aa87610068e796f17ded3a9033f5bcf37ca94b7257864bff1000b3eaffe69d.jpg",
              "67a.jpg": "embedded\u002F3c51514f31f59c80f7749789077b2440145a87e68c34f811c72f4ff817259229.jpg",
              "67b.jpg": "embedded\u002Fcbcca974e8bf611ffab16c857a8fd5078698aef2b3bb181ec98140be0931a909.jpg",
              "68a.jpg": "embedded\u002F4105b29555c9d2b086ecba73e6d4365780e21f35feeda5da3631acdeda8f85ca.jpg",
              "68b.jpg": "embedded\u002F5df078b3b48f256ad73a40f2297a389c39d7cd57904a246467d033d6b3cf551b.jpg",
              "69a.jpg": "embedded\u002F52fe303156f6ca7fbfb62edbea689ccf93b8f5e2881fe0acb2917e4d2b45f0f6.jpg",
              "5a.jpg": "embedded\u002Fc84c32ed2241c80634cc3a55cbb5259dec4d5acac87f33e047b3548c9cd7f426.jpg",
              "5b.jpg": "embedded\u002F2fd86f552f35de7fdafd5e0f426145d8df3a2fd5947bcb62247744cda36ed638.jpg",
              "59b.jpg": "embedded\u002F8412d64680a712f4392affc8f9015270ec2f6e0b257c6d2e18aadfe367f4f04a.jpg",
              "60a.jpg": "embedded\u002F31e5b49109aa9297815a826ff87e2a1fa07025162b67c70777bf377d385b1b13.jpg",
              "60b.jpg": "embedded\u002Ff13817b043e28c11a7029c1042448044688c4297d282386daf04c08bf923972a.jpg",
              "61b.jpg": "embedded\u002Fc52ddb7216854a649cfcaf52b4fe55fd56965dfd475cf87946fbab2c765bebee.jpg",
              "62a.jpg": "embedded\u002Fec87ca5f57c464cb8436e092df41752342e11ae9120968555302a17b72765360.jpg",
              "62b.jpg": "embedded\u002Fbd1c552d3041b9b7b5fcc4e25d89aea5e2a8eb6bfc2c3f040a2c94975a8ff1ab.jpg",
              "63a.jpg": "embedded\u002F929310f118a3641408685a993311000ab2cb7b614e0120f99fdc0ab1ace1a093.jpg",
              "63b.jpg": "embedded\u002F6ab1fb1f95db1a4befb7bb1e1773cf11971a0d6beea7adb372204a3e2a2495c7.jpg",
              "55a.jpg": "embedded\u002Fcf5ded7375b6087463c79b610f05a47038bfc67bd9f70d7f8ea68d5a06369464.jpg",
              "55b.jpg": "embedded\u002Fa08ecdf635d164373491f61f641139cb4f4cd7a95b553965c4901ad01013b695.jpg",
              "56a.jpg": "embedded\u002F2f2052ce44a1be84d49d89b0dcc23406c0790ff8158ee5c0dae8d1588705b836.jpg",
              "56b.jpg": "embedded\u002F3cf14b29c27519f58a08de872fa087d66761716fefb03f1e8cdbc73188c253ca.jpg",
              "57a.jpg": "embedded\u002Fc4c4432146f4ad85b003c08b8877da8b7da9f0197749df4dca9909322d6c3588.jpg",
              "57b.jpg": "embedded\u002Ff93d0a98def7debb10d4daf2a07d5fabdf610eba8594b415594f8674a73bebcd.jpg",
              "58a.jpg": "embedded\u002Fb6ec70005d2910a3e6f3ddbc3d6241c455da8d8c6d3880a949c00b4be48444cd.jpg",
              "58b.jpg": "embedded\u002Faed8bbd545acf6013ba36f8dbccc40af5265a75729435aa76bedae871da529fd.jpg",
              "59a.jpg": "embedded\u002F9361bbc1b037b753dd1be6f70781af1aa6440fa83fcf0c4d67c87c76fb5f765a.jpg",
              "50b.jpg": "embedded\u002Ffe1b977570da018787963087f7baf763b29a6842965109064068aca286706e07.jpg",
              "51a.jpg": "embedded\u002Fcf616a3a0410cf888ac7526fb6d5d4ab591485593a4d20aae628aa997612a1ee.jpg",
              "51b.jpg": "embedded\u002F198aafea57acb87c827cae5e29323c36ce1f3d5d2c042b3c4268b51a550ed522.jpg",
              "52a.jpg": "embedded\u002F69c4dcae4cc4c9870e672f60a248f4e16a415785f002a1804a6ce90a34429fd9.jpg",
              "52b.jpg": "embedded\u002F73d30127b516da3d1da2deaaca2bf14ca73e0e03c2f51719fafde46d4e58cb1f.jpg",
              "53a.jpg": "embedded\u002F3cdf04733c11d51635a384a2ae4ee19c4663e95a3a87f13c7c6b19f2a0801b95.jpg",
              "53b.jpg": "embedded\u002Fc2a7780bd2b33dc5c32e87a0e02a7166eefda71ffe1d5720dba8cfa47a963453.jpg",
              "54a.jpg": "embedded\u002F70ed008a752151378cd285319f361dcfc79319d9ceb2c301314547f1035f24c6.jpg",
              "54b.jpg": "embedded\u002F436e0f31b43c78bd366d2210bae8d12b9cb62c8eb4f309874c5a5e68db824de4.jpg",
              "4a.jpg": "embedded\u002Fa0d2b5073234d4134bbc00a108738bf837af3cc8f3a0f6477dc36b4845a0b6ad.jpg",
              "4b.jpg": "embedded\u002F322ecbd1a5726405a8e168254aa6a4df5719c9da41e3e87e11ba2535ae56805e.jpg",
              "47a.jpg": "embedded\u002Fc1ff6565d740a4ac6520fcf6a4b0817c202f3f08fe101eb431b5da99f3548948.jpg",
              "47b.jpg": "embedded\u002F694aabd9e0f521794b68f5e0d1bd10c1ec825678934a90e34b0365143b36da7d.jpg",
              "48a.jpg": "embedded\u002F1daea8f0c8d203d7b6104e8bdf7d72e4cfec7ff5aaad91b52cbdd8c1eab66735.jpg",
              "48b.jpg": "embedded\u002F1f891355d8ca7b2fb74f0e5b06dbfc9ea7822a91afa8ff7363ea49c37c6f9d6d.jpg",
              "49a.jpg": "embedded\u002F2b66d50f36539639aac62d36905413d8d9ee6ddc8ba915c9ce626deaa2b70582.jpg",
              "49b.jpg": "embedded\u002F2eff458cd2168152481f11647b4370f18ed10af5501d9c0be7242a2be580db97.jpg",
              "50a.jpg": "embedded\u002F3d113d40381df7c00f0c687490d49fa44438bdb30afe0d4351c94ef1008e687e.jpg",
              "44a.jpg": "embedded\u002F66f4d9e8063a969a345f33cb33977e93ec3a344d053c34083433316054d3d049.jpg",
              "44b.jpg": "embedded\u002F2d49feb5f46764d4ec9d81c826c35a6078f7a4286529559ab729056cea52c39d.jpg",
              "45a.jpg": "embedded\u002Fbe971f57e30078da566798b3dad694543670042d67e707bc0de2c68a43992f65.jpg",
              "45b.jpg": "embedded\u002Ffdc2a57d44213c98cb7d2114bb574de4e39162c88b4018557efdeeaea3eaaf8d.jpg",
              "46a.jpg": "embedded\u002F3119ddaf4702d44d8ee0c97d141e77b953fd27fcf6a59bc731e9be1097d976dd.jpg",
              "46b.jpg": "embedded\u002F06cff9b0327e6ead3aeb15d429aa8ae68f1bcd152c70cdae2aca1120d7f91018.jpg",
              "3a.jpg": "embedded\u002F671dacc8499b31e4524dca978cb7d882e0744fbbcf5a0060e125cd7e46e7f022.jpg",
              "3b.jpg": "embedded\u002F4cf46bd6ab9dca232307e348dcb0bc6d4d6b9e5078f80807018e8dd7b9466472.jpg",
              "40a.jpg": "embedded\u002Fb821c8de92e2238f958d7af50f2c2ee5022b0169089f56c1d52001c1c5ad7c2c.jpg",
              "40b.jpg": "embedded\u002Fc0cf61a9bf9aa28e45a5cb1c8990ad4ee3c0dc9cc0de62120c9efed5c29b3201.jpg",
              "41a.jpg": "embedded\u002F419d92d08ea374f28f897cd8dd6f9aeb79a94d306b2f6e6acf90347e9cd1e589.jpg",
              "41b.jpg": "embedded\u002F4cda2abaa9aae38d03104c44f95fc99244b7b5713eb0389556345cb3d1fe3fd9.jpg",
              "42a.jpg": "embedded\u002F475690cb3766d9e2d7ffbe05c97ca5a5582944f2a3a1911c4164fcbd16fed368.jpg",
              "42b.jpg": "embedded\u002F0cf1383fe842f3ba2e40a2f8066f27834f56dd14eddf7e654bc585f74286e3bb.jpg",
              "43a.jpg": "embedded\u002F6bb26fcfabb8e9e49047356bf267a47d3d3c0263834ebfa046f1c615d82c3626.jpg",
              "43b.jpg": "embedded\u002Ff8a67254e4f7b1473aa1de4aa749b164ab257e45be7a7bf7ce2dbd03a1aee15c.jpg",
              "31b.jpg": "embedded\u002F4832e3d6fff903c35df37ec3e3e260a617975ef1960b6461bf19b86da7cfa57b.jpg",
              "32a.jpg": "embedded\u002Fb45bfae45b40c7ed38b1d598097ab47e7aa70d1a9c323e779637832b17d4527d.jpg",
              "34b.jpg": "embedded\u002Ff0d23c5ecad8461f682cdeb1a899b52590e209c82f2e653d03a00ce81768d19d.jpg",
              "35a.jpg": "embedded\u002F875b97d703ddffe15b2947a3627be128d7814ffc1b9eb1fcf1f56024d7f23ce0.jpg",
              "35b.jpg": "embedded\u002F46f35f94afbf751395f7818a290310823df4f4645494ccd75087d22d81381739.jpg",
              "36a.jpg": "embedded\u002F2c9cc33f95cd6cd705de128b4eceef47881e477af9ab3a7f55e8bc59a03e3835.jpg",
              "36b.jpg": "embedded\u002F3530503d7bc2630f7fd631d00745cc9a7f8d6e94e30fb43819e25518f3ec698a.jpg",
              "37a.jpg": "embedded\u002F64b44abd77cfc023d123a09b29194c15e4a89c65ddb293f6c00d535b1147ec9e.jpg",
              "37b.jpg": "embedded\u002F1325c83e10231adf31376491e6745853c8ac845c3ee7ea7d7e22b7325bf78add.jpg",
              "38a.jpg": "embedded\u002F992bceff0687fe6caf3553cbe13fa5917e08ff7eda633b357aaaf0895ff8e4cf.jpg",
              "38b.jpg": "embedded\u002F62d76b2bb527a9b95fd9fe329c298422e1991470c90bc5d2ba195ad8dfe078b4.jpg",
              "39a.jpg": "embedded\u002F3dd2fbfb9fa5f02e4f09d03bf243f819774a1e9e00e39e0340f1d0f9f7ea6126.jpg",
              "39b.jpg": "embedded\u002F23888bce5be0a9772fc5ba9f1a35aec85e8e775bbd74e3e6977d35eb98d27eb0.jpg",
              "30b.jpg": "embedded\u002F8275e23516727f3f62d7d5e6807a16477f464e726a03c92a958cf4a9d0a4feb6.jpg",
              "31a.jpg": "embedded\u002F60138d95bc4472a3e34083a0fe15efa71efefe159d24d10c4a458f5b284ed165.jpg",
              "32b.jpg": "embedded\u002Fac335bbbdee458eedb9e291bebb14c79b8b3746316f8f067976cc8a98276dd43.jpg",
              "33a.jpg": "embedded\u002F136e1689d01634b001409ae680543a7b4c0af29ef4a82f623c10dd7d0983e17c.jpg",
              "33b.jpg": "embedded\u002F71da3e2e4948c4cb6e7a0dc8910bf316f195dab828511b37580bc99a6a4d2deb.jpg",
              "34a.jpg": "embedded\u002F9aefa35f66c7fef1ef81d5e0709bc9330f2a04a5a6d3328734c0a1802dd1ff4f.jpg",
              "2a.jpg": "embedded\u002F3da555a0d815725e71d82e9bd447f46e41192b0d610b19eef3960cf64b67fa3b.jpg",
              "2b.jpg": "embedded\u002F211d8af1b51e46dafedb3a63402175262e7183b1fce058ad42cbb49b6bffce7c.jpg",
              "26b.jpg": "embedded\u002Fdb796c1f96f26161b6ea6ed10d7bca18e30c27c4c4d93b0a14b1d0b4548866a8.jpg",
              "27a.jpg": "embedded\u002F236630eac5fbf4c1ebe1c3a7fe0366081e24092dd8804bd178243cbff9e38581.jpg",
              "27b.jpg": "embedded\u002Fd0af6af3e54b9ab4b48b6c1bdea44b87a464b6bb75d192881d2d410530fca42a.jpg",
              "28a.jpg": "embedded\u002Ff5cd7ba103f0ae18b3e43ed3fc08baa2610d474e0cc550648deeaff4b886b44c.jpg",
              "28b.jpg": "embedded\u002F8f62ab997fc70d089ecfa38e5c0600afe90fdde724e5b2c55807ef44dceb7b37.jpg",
              "29a.jpg": "embedded\u002Fc7df5e9782529cac80d8965959fa411547ac86acaaeca388bc3c856f36178d68.jpg",
              "29b.jpg": "embedded\u002Fdac5cece9a7ff24a46eeb52895a9f1a534b61e425f7a61a94c68d157bb3e8b09.jpg",
              "30a.jpg": "embedded\u002Fe751adf184cd5cd41e478ef505a7ddcaa5a776d5c91e90e8bf5a58064acd0362.jpg",
              "22b.jpg": "embedded\u002F2380ce0098c499c1726627923e7588f384d73f7914e0d0bbee062771a89ca4e0.jpg",
              "23a.jpg": "embedded\u002F0d82cf569a4acc3d501424321b5e8a590b91b6ca885dba12462f9fd3a0d56213.jpg",
              "23b.jpg": "embedded\u002Fb0aa18da30427cff3400a66ca5fc7bbb5f77637e1677be1f2da052fa5f25c9da.jpg",
              "24a.jpg": "embedded\u002F1b735824ec75ec7598d1eaa6197aada4e64771128fe7748d22a3df4c63155e9c.jpg",
              "24b.jpg": "embedded\u002Fe86a28829c424c1e92e54689a5d167707a86377f720d8d34a2b8140d85afb8f8.jpg",
              "25a.jpg": "embedded\u002Fdbf5d964da17f282c29c2d5a87d3bbf85eb1f3f0b87bdb3ff720a73457a5a217.jpg",
              "25b.jpg": "embedded\u002F474e35e69af74c6518c9db7ec22c78fccb582ef09f36d12abef5f844d1022947.jpg",
              "26a.jpg": "embedded\u002F9457890f41392bcf72fa706c5e72da81322f920a49fc921415677f104a1d6c0e.jpg",
              "1a.jpg": "embedded\u002F40ec0aeed5a00fd0f9b99f4b35a1aa7c29c8ff676f841814e890cb6514c7c939.jpg",
              "1b.jpg": "embedded\u002F0ccadce9c0f474d481f138ba342be1608522d7548d3407eed47139a6bf1bed76.jpg",
              "19a.jpg": "embedded\u002F1083bf3e7b667c7ea0fb84d39a3bb24a4faf2376f67aab219d9afaa136ee1899.jpg",
              "19b.jpg": "embedded\u002F4590fd824e6f975e96ed1362b1ee8142ebe281f1fc44aecf7345935ce7ce3bb6.jpg",
              "20a.jpg": "embedded\u002F58ef4883702d9a3f4913c8ae62cdfd7b146af3e5e9b78e354c6acb4225934e0a.jpg",
              "20b.jpg": "embedded\u002F38e0c5b07d737a31268cced522e9b04dada31cd5dd909a415fc30c2e0cc00d5b.jpg",
              "21a.jpg": "embedded\u002Fddac78ace94bd6222c5e34d6884dffb2f955adcb5c09bf19cc78c96fb10e2988.jpg",
              "21b.jpg": "embedded\u002Fc79a2f3334cf0be5fb78acdb9d109f1a6a7885460454cf065526ac3302c254b7.jpg",
              "22a.jpg": "embedded\u002F4fcb1eedb49dc9fb3cd31c4af6c44ba9409c02c2b40daec9d5f3021bcad37183.jpg",
              "14b.jpg": "embedded\u002F47a37415a436466d108eeec5cb5ee9f6925cef2d93f674b5ddbbf94f4c791635.jpg",
              "15a.jpg": "embedded\u002F0f7de3d6b4f616e41e63e05419b4866ca99d6e4bda8329a7a98b71e3be244ca2.jpg",
              "15b.jpg": "embedded\u002F38c62870b80bd5a68c821da1b2faf0898dfd793c6be99e69bc43580a2710c872.jpg",
              "16a.jpg": "embedded\u002F730c9d43ab6269c45b012c00fdf9c8236c69bcdac6506e320191bec0c2043902.jpg",
              "16b.jpg": "embedded\u002Fb35a04e8a2ea8785360700f55371ad6eec1a129f8b8173bb24f9809983a4d40d.jpg",
              "17a.jpg": "embedded\u002F1d7c4381c6f326c5f112618420853583e923988cd940ed73b997d719051339b0.jpg",
              "17b.jpg": "embedded\u002F46c23dcf5cb7001486dbc5a681af51abd0281634ac148aa9d67f92e14fcb6fe4.jpg",
              "18a.jpg": "embedded\u002Ff4fbf2921510640c6652f73a842476fcf98a83ab6e689e89a0c084f5586b0a67.jpg",
              "18b.jpg": "embedded\u002F4e120ca73c66b1f27bcb706d1039573e1860fc420ccab0528811bd181a1b5501.jpg",
              "10a.jpg": "embedded\u002F0ee328b416d9c5d1f8b4e19d75bc3b1b00f095378de2800da787501313ba5f17.jpg",
              "10b.jpg": "embedded\u002F0a85f4b434cc1dffe821f9e0519e659a035d9e6e6b73fd3cde3264983a7c86d9.jpg",
              "11a.jpg": "embedded\u002F09487ca861c9e8e0b46613104869b9d2376b1c77cb269cc7dbe6089e0a4a1f79.jpg",
              "11b.jpg": "embedded\u002F309beae8a6f4cf09ee779515b14a12e1f843ff060dca94c687c1e53216a184ee.jpg",
              "12a.jpg": "embedded\u002F85798de537a8035f97574a8d9ba2b806342b4daa98e75c62c1e39223b8b5fe68.jpg",
              "12b.jpg": "embedded\u002F6e34a055eb67e4d96c5524d3b163fe43df91f9970bbf5b69b7d2d5ce60b01f66.jpg",
              "13a.jpg": "embedded\u002F84075ce0f841293161268199ea2019ee2b87da422efc6c6fc47883bf3d020f77.jpg",
              "13b.jpg": "embedded\u002Fc361e96137bb62cb18d5d7f6cfaa10366d289eba79c5dc4862338e05c1095162.jpg",
              "14a.jpg": "embedded\u002Fd0a90b5a88ec7893581852dfa4833c7e08c43f4a83d4770ef710e5ec4f065ea2.jpg"
            },
            "responses": {
              "": ""
            },
            "parameters": {},
            "messageHandlers": {},
            "title": "initial decision"
          },
          {
            "type": "lab.html.Page",
            "items": [
              {
                "type": "text",
                "content": "\u003Cp\u003EPlease rate your confidence:\u003C\u002Fp\u003E\n\u003Cp style=\"font-size: 0.9em; color: #555;\"\u003E\n  Use the slider below to indicate how confident you are in your initial choice, where:\n  \u003Cbr\u003E\u003Cstrong\u003E50%\u003C\u002Fstrong\u003E means \"I'm just guessing\", and\n  \u003Cstrong\u003E100%\u003C\u002Fstrong\u003E means \"I'm completely certain.\"\n\u003C\u002Fp\u003E\n\n\u003Cdiv style=\"width: 60%; max-width: 400px;\"\u003E\n  \u003Cinput\n    type=\"range\"\n    id=\"initial_confidence_slider\"\n    name=\"initial_confidence\"\n    min=\"50\"\n    max=\"100\"\n    value=\"75\"\n    step=\"1\"\n    style=\"width: 100%;\"\n    oninput=\"document.getElementById('slider_value').textContent = this.value;\"\n    required\n  \u003E\n  \u003Cdiv style=\"display: flex; justify-content: space-between; font-size: 0.9em; margin-top: 0.25em;\"\u003E\n    \u003Cspan\u003E50%\u003C\u002Fspan\u003E\n    \u003Cspan\u003E100%\u003C\u002Fspan\u003E\n  \u003C\u002Fdiv\u003E\n  \u003Cp style=\"margin-top: 0.5em;\"\u003ESelected: \u003Cspan id=\"slider_value\"\u003E75\u003C\u002Fspan\u003E%\u003C\u002Fp\u003E\n\u003C\u002Fdiv\u003E\n",
                "title": "Initial confidence"
              }
            ],
            "scrollTop": true,
            "submitButtonText": "Continue →",
            "submitButtonPosition": "right",
            "files": {},
            "responses": {
              "": ""
            },
            "parameters": {},
            "messageHandlers": {},
            "title": "Initial confidence"
          },
          {
            "type": "lab.html.Page",
            "items": [
              {
                "type": "text",
                "content": "\u003Cdiv style=\"\n  position: fixed;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n  font-size: 64px;\n  font-weight: bold;\n  text-align: center;\n\"\u003E\n  +\n\u003C\u002Fdiv\u003E\n"
              }
            ],
            "scrollTop": true,
            "submitButtonText": "Continue →",
            "submitButtonPosition": "right",
            "files": {},
            "responses": {
              "": ""
            },
            "parameters": {},
            "messageHandlers": {},
            "title": "+",
            "timeout": "500"
          },
          {
            "type": "lab.html.Page",
            "items": [
              {
                "required": true,
                "type": "html",
                "content": "\u003C!DOCTYPE html\u003E\r\n\u003Chtml lang=\"en\"\u003E\r\n\u003Chead\u003E\r\n  \u003Cmeta charset=\"UTF-8\"\u003E\r\n  \u003Cmeta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\"\u003E\r\n  \u003Ctitle\u003EImage Randomizer\u003C\u002Ftitle\u003E\r\n\u003C\u002Fhead\u003E\r\n\u003Cbody\u003E\r\n  \u003Cmain style=\"display: flex; flex-direction: column; align-items: center; gap: 5px; padding: 30px 0;\"\u003E\r\n\r\n    \u003C!-- faces and ai_image in a row --\u003E\r\n    \u003Cdiv style=\"display: flex; justify-content: space-between; width: 150%; gap: 350px;\"\u003E \u003C!-- Increased gap --\u003E\r\n\r\n      \u003C!-- faces in column on the left --\u003E\r\n      \u003Cdiv style=\"display: flex; flex-direction: column; align-items: flex-start; gap: 10px; width: 40%;\"\u003E \u003C!-- Set fixed width for left side --\u003E\r\n        \u003Cimg src=\"${ this.files[this.parameters.image_a] }\" alt=\"Portrait 1\" width=\"180\" height=\"220\"\u003E\r\n        \u003Cimg src=\"${ this.files[this.parameters.image_b] }\" alt=\"Portrait 2\" width=\"180\" height=\"220\"\u003E\r\n      \u003C\u002Fdiv\u003E\r\n\r\n      \u003C!-- ai_image on the right --\u003E\r\n      \u003Cdiv style=\"display: flex; justify-content: flex-end; width: 20%;\"\u003E \u003C!-- Set fixed width for right side --\u003E\r\n        \u003Cimg src=\"${ this.files[this.parameters.ai_image] }\"\r\n             alt=\"AI Decision\"\r\n             style=\"max-width: 400px; width: 250%; height: auto; object-fit: contain;\"\u003E\r\n      \u003C\u002Fdiv\u003E\r\n\r\n    \u003C\u002Fdiv\u003E\r\n\r\n    \u003C!-- buttons --\u003E\r\n    \u003Cform\u003E\r\n      \u003Cinput type=\"hidden\" name=\"final_decision\" id=\"userSelection\"\u003E\r\n      \u003Cdiv style=\"display: flex; justify-content: center; gap: 40px; margin-top: 20px;\"\u003E\r\n        \u003Cbutton type=\"submit\" class=\"classification-button\" style=\"width: 180px;\" onclick=\"document.getElementById('userSelection').value='same'\"\u003E\r\n          Same\r\n        \u003C\u002Fbutton\u003E\r\n        \u003Cbutton type=\"submit\" class=\"classification-button\" style=\"width: 180px;\" onclick=\"document.getElementById('userSelection').value='different'\"\u003E\r\n          Different\r\n        \u003C\u002Fbutton\u003E\r\n      \u003C\u002Fdiv\u003E\r\n    \u003C\u002Fform\u003E\r\n\r\n  \u003C\u002Fmain\u003E\r\n\r\n  \u003Cstyle\u003E\r\n    .classification-button {\r\n      font-size: 18px;\r\n      padding: 10px 0;\r\n      text-align: center;\r\n      cursor: pointer;\r\n      border: 2px solid #333;\r\n      background-color: #f8f8f8;\r\n      border-radius: 8px;\r\n      transition: background-color 0.2s ease-in-out, transform 0.1s ease-in-out;\r\n    }\r\n\r\n    .classification-button:hover {\r\n      background-color: #ddd;\r\n    }\r\n\r\n    .classification-button:active {\r\n      background-color: #bbb;\r\n      transform: scale(0.98);\r\n    }\r\n  \u003C\u002Fstyle\u003E\r\n\r\n  \u003Cscript\u003E\r\n    \u002F\u002F Function to randomly swap the images\r\n    function randomizeImages() {\r\n      \u002F\u002F Randomly decide which image should be on top\r\n      const order = Math.random() \u003E 0.5 ? ['image_a', 'image_b'] : ['image_b', 'image_a'];\r\n\r\n      \u002F\u002F Swap the image sources based on the random order\r\n      const imgA = document.querySelector('img[alt=\"Portrait 1\"]');\r\n      const imgB = document.querySelector('img[alt=\"Portrait 2\"]');\r\n\r\n      imgA.src = this.files[this.parameters[order[0]]];\r\n      imgB.src = this.files[this.parameters[order[1]]];\r\n    }\r\n\r\n    \u002F\u002F Call the function to randomize the images when the page loads\r\n    window.onload = randomizeImages;\r\n  \u003C\u002Fscript\u003E\r\n\u003C\u002Fbody\u003E\r\n\u003C\u002Fhtml\u003E\r\n",
                "name": ""
              }
            ],
            "scrollTop": true,
            "submitButtonText": "Continue →",
            "submitButtonPosition": "hidden",
            "files": {
              "140b.jpg": "embedded\u002Fdcccd663d5af1da58a1375acac0fd2386604b75eeb655d1cc8f25fb92a697133.jpg",
              "140a.jpg": "embedded\u002F26ae622b6033f7d96917e75ec106d606e0cd4f8e4543919a66c637b52f34d76b.jpg",
              "139b.jpg": "embedded\u002F092d705859deac34f64abd5d08cd6ff8235a2af3f4a65be0ef908d9a2b40c7c6.jpg",
              "139a.jpg": "embedded\u002Fac69da592d2229c081572cee0dcea00cf794b802677d6765be7ff5b1161d89ec.jpg",
              "138b.jpg": "embedded\u002F7e84295f28860ac905186ca0ec20bbb6a0267414af8188e53d00907c34594400.jpg",
              "138a.jpg": "embedded\u002F26e1bd71230ea0777d3526fa27e031e8847ca25d2e1a3298b6ed3794e76fc5cf.jpg",
              "137b.jpg": "embedded\u002F77c866aa15472376190495140c84ac69bc87d6df028f856adc4af674908cad8d.jpg",
              "137a.jpg": "embedded\u002F52e5d115f5474eba7230fc7a83550383655b45de2e960e926e0feaad05ae6984.jpg",
              "136b.jpg": "embedded\u002F59e8e48977f0f988abf68beba79a137797e86faa622aa9114f9fd728a25190e7.jpg",
              "136a.jpg": "embedded\u002F3892f7276471bfe7cb60b6ce49c816f76c182d8b199337477c7c494f74b8cc20.jpg",
              "135b.jpg": "embedded\u002F0b5d56393044b8e89ad4552866da284c9f0114ba33cd5c7db66067cc5600e4ad.jpg",
              "135a.jpg": "embedded\u002F66577454e29e20fa4aaad672427920541759c3fb53236ec4a37e802b7e418f2a.jpg",
              "134b.jpg": "embedded\u002F0ba3b23e7f8442fc4788d9408dae0e53359ff99756e2d328813577e8956ca635.jpg",
              "134a.jpg": "embedded\u002F3954e7151dcd21d2db1c6d81186ac90cb1ce54f8749e9e2612f26f463beeb0db.jpg",
              "133b.jpg": "embedded\u002F59b52c324905bc9a441567b6b00d2629113ef6d8ae598c635d29cd7842fe7c95.jpg",
              "133a.jpg": "embedded\u002Fbd66c9515e0e0edad8ac585dab9999dc2ade751acf7de036e95bebddf227dafc.jpg",
              "132b.jpg": "embedded\u002Ffe4bc12413c692e078767ff6d53932ee4bb391c47ff5ee1095e155d119361896.jpg",
              "132a.jpg": "embedded\u002F3fbb547607814fb14bedccab40290df125a1282403a157f64cb4923756004cee.jpg",
              "131b.jpg": "embedded\u002F29259c20f87338e69f904cb858876b7a428faea1fae3af51214ced1170e4abc8.jpg",
              "131a.jpg": "embedded\u002F088e2be9bd8c228f7a33d8f56fbb7bdc2ec0adb73bb313268fd618e446c31ef6.jpg",
              "130b.jpg": "embedded\u002Fc92d23d58942e28ec555455a6df2ceb6d7915d55ef923834d7c4454508ef1071.jpg",
              "130a.jpg": "embedded\u002Fbf7bdcb961b8e6adb0a7691c4416c4011db9c26bc697f8cdb56d27ee896476f8.jpg",
              "129b.jpg": "embedded\u002F5795d5df29ff31d836e38810f6ab8406c5167d058747974d91a326ffafb7da97.jpg",
              "129a.jpg": "embedded\u002F6df0b8622c53c440a9d607f530ddff6dbff50dd0534bf24b22f4b0eb09c79607.jpg",
              "128b.jpg": "embedded\u002Fbb20840e6e0dbbbe916e1789e76b03836c94921864a23affedce3404f6895a59.jpg",
              "128a.jpg": "embedded\u002Fd9705e9ceb3042b58b44976e076364a7ad0bb1c268bca5be266626437fc84acb.jpg",
              "127b.jpg": "embedded\u002Fb7039bfcad848ff1e9cb62aeda97bcb8718ce69efeabecb545867e98c6660465.jpg",
              "127a.jpg": "embedded\u002Ff9345bb52da83f9c91db7641becebd304950bf8691f4bd80c77c624f3c8958fc.jpg",
              "126b.jpg": "embedded\u002F7ad5cdf60bf524c40fccf9eac2043d11eaf24b4a39c0ed8734563aec0fa15515.jpg",
              "126a.jpg": "embedded\u002Faf806ce0a0c326747104d2c1c85da7502c9d46c7f1bedb19cdae5e36db844f3f.jpg",
              "125b.jpg": "embedded\u002F1ffa8e4470ff1a078b723883e1ca59f1c2b709baefaaef5f3e0b724213caa730.jpg",
              "125a.jpg": "embedded\u002F243e43c7b8702e99ace48337bdb7341172560d3f28f6657abe79d7bc006aa926.jpg",
              "124b.jpg": "embedded\u002F25b4988292cb2f46e4a4b4d7e44223b3da7274dad9a6b999e41a5de84a4ac264.jpg",
              "124a.jpg": "embedded\u002F4c9dcae1a3ea253417d7a17a0d3b5c48d2a244f34c984d8588ff21e4738f5c47.jpg",
              "123b.jpg": "embedded\u002Fc0786d9028f7d195e2a3009f369545decd0aa872be089f9a320fa1adfd0587b4.jpg",
              "123a.jpg": "embedded\u002F6ee8ccb9ff758f221c2732ab497cbfb8bf8a28616b4a883e449a9be50b55d96c.jpg",
              "122b.jpg": "embedded\u002Fd9a20991436a599457b2a6b8a3da2031bb68bc8c0b19bb8320a1790b4cf4d6b4.jpg",
              "122a.jpg": "embedded\u002F33bcfbd87f53cfd0d8646ef1e17d794fa163e54f3bdfcb5e4452a24ce7426edc.jpg",
              "121b.jpg": "embedded\u002F3751368659ca5d441dae58c6a3dd436a4242bbd23a2fc10ac8af6f2b4d60e78a.jpg",
              "121a.jpg": "embedded\u002Fb5fc03ab8f41ce797c928dd908340da0b62c6c9c4b1ac760327544e932f7ae17.jpg",
              "120b.jpg": "embedded\u002F70ed906f796fb7e42c6bf28a6b48f798a9df16be40bfdc8931f4ee1854b8c663.jpg",
              "120a.jpg": "embedded\u002F1bcbaf8f440c1710f50af7d4ede81f2fabcfa04c8850087b91ad039b8a52c8f4.jpg",
              "119b.jpg": "embedded\u002F84f6977ee319392479f28ffa07f2c18a40c7cecf3d41aad84697b5358097856f.jpg",
              "119a.jpg": "embedded\u002F430b5b114e0469901b7c5c63b9d9e4eed37701928ae3f4d6bc362894ffb7deb2.jpg",
              "118b.jpg": "embedded\u002F9feac0be667a2718ee58207c16125c7da5bd628f4ec94c61ec249876510e9df4.jpg",
              "118a.jpg": "embedded\u002F65714fb6e858edfe228fef89848201acc3d1b1b594a23791b09d146d259b742e.jpg",
              "117b.jpg": "embedded\u002F1a7f733484fd56fceb8c1531c59a3262c42eba0bf034da90d2ccb2dbfa1aa4c0.jpg",
              "117a.jpg": "embedded\u002F308e877ba9f63f8734e6ba45849bff34129a7659e1b54a90a8ea2de8c281879a.jpg",
              "116b.jpg": "embedded\u002F56536b49a971a0a1cea02ac14bc648c35505c2bb86aafe69436525802d17408e.jpg",
              "116a.jpg": "embedded\u002F337319549c90ba1d35d4441cca9c6ab903d10db7f39dc331a67e458e24de0a99.jpg",
              "115b.jpg": "embedded\u002F83168bcec95c2eae0d1d523ae1668a96e9d2e1ff24b489b5d3e11c60e62aabb7.jpg",
              "115a.jpg": "embedded\u002F35e9c207a0d8e29179d7c6c2c0497405c4807b85fff9c331f2f9c5ba6dc22d24.jpg",
              "114b.jpg": "embedded\u002F18d3c6bbabc85f406a936d4059f04768d478933c96ee9b4806ef60d69b9db618.jpg",
              "114a.jpg": "embedded\u002Fe87866b83ad3c770eebb47c7fd9debf236496c7bc72f320a43b0be8a84716df5.jpg",
              "113b.jpg": "embedded\u002F0116ca98ee2edbcae4c0229e4677c88494df9ad0e99aff3cb7bbe9fd7d952a42.jpg",
              "113a.jpg": "embedded\u002F429c2a5f02dd6bca04447de85c5d981e23cd747125330cb64ad04bf7804c6264.jpg",
              "112b.jpg": "embedded\u002Fa1efe8c8a9967e8dd7668afcf7c892c2ec4610e6ae61781be4900d88e96ede74.jpg",
              "112a.jpg": "embedded\u002Ff5d434effa2263eb7cffe6c5af2678f646a13a660bd80b3ce3985ab1f030f81d.jpg",
              "111b.jpg": "embedded\u002Fff131609c3b1b7696a6c5ff364845fb67f82f0301254bc33c1328c4b3119ef95.jpg",
              "111a.jpg": "embedded\u002Fc22a550045de72d117c0679c99d422cd9998b372f819b71e4b505c5f795675fb.jpg",
              "110b.jpg": "embedded\u002Fae2a5a5e4a62f3f7d4717576efec87b9369c140b912cd1042170f23084e861e0.jpg",
              "110a.jpg": "embedded\u002F85e24f289e269a25b41254d5fb5b732dd11b5b187ac6efca9dbd1bff9ab7be0b.jpg",
              "109b.jpg": "embedded\u002F105368e75cdcd5cafc108523d1b5bbc18f9f02c15e505f8284d554b384e80119.jpg",
              "109a.jpg": "embedded\u002Fc4b1b523ed900ac5574cc16441ada2e916f511b84bf41e591a925415065c2ada.jpg",
              "108b.jpg": "embedded\u002F2d01064cb90a1a112030e42e5a6801b594d25b8949f971869f4aa8b24d072fa6.jpg",
              "108a.jpg": "embedded\u002F2a1dfa634d0bad4b1629e3d78b8db6fdb0d266594d237f1bcf11b53c8550e3a2.jpg",
              "107b.jpg": "embedded\u002Faec4ec4ee09b6c66ba7bb0326707e6a8747ce1717243d1f13e84c4644dbbd3ba.jpg",
              "107a.jpg": "embedded\u002Fee953deab1177e2d8021e223be1cbd9a89870a5baf7fe247d9e5806da79b86ba.jpg",
              "106b.jpg": "embedded\u002Fa339be7cc6960dcd14b47362ed8ae65fe2e6ff280c971d6344dbae4fa539058d.jpg",
              "106a.jpg": "embedded\u002Fb44f1254a8ff29f69c2af85b4148920c7cd7f135d763a1bfa45b7f60e0030be0.jpg",
              "97b.jpg": "embedded\u002Fe316d92706db3aa9bba1fbff3b1d08f95ce32d117b6c4bdab59907d887e5743f.jpg",
              "93a.jpg": "embedded\u002Fdba32cb6a231f1512888156d561f6f28061ffb07a92bd6e72d97b419137aa98c.jpg",
              "93b.jpg": "embedded\u002Fdb1600f9d48af877ad1efdd9579846200f68bdcc1895658ae8bbac0803f28508.jpg",
              "94a.jpg": "embedded\u002Fabc8f84e11fd1c6ad9c6a1f9525761abb800d2780a479b12e89f0780f862ff07.jpg",
              "96a.jpg": "embedded\u002F6e12ab22a36616cb9dd9f824adf54b644657bfe2d27bf0ac654bd9c15de4a9a4.jpg",
              "96b.jpg": "embedded\u002F1834b0d790e0da9ddd6158884cc96e0f0d4715a9d8def0a6360dbaaedd9e62d9.jpg",
              "97a.jpg": "embedded\u002Ff9394b86dfe33347cb5b3271c6b97d01a3b462ed286f8d6fff8b87e9aa6a47c5.jpg",
              "98a.jpg": "embedded\u002F1eca0ebfc9b7c40b045491fcca9fedd96bbfd9815c7cadac5a82e14035a84df7.jpg",
              "98b.jpg": "embedded\u002F9c8a7d510e9d7cb6ab5b1f24dca9b5596aaa60c57f75be940c91c3dce4fba1a6.jpg",
              "99a.jpg": "embedded\u002F367f1a9187c18ce419c2876b2f0b28de6c48a7d7522e55c28065772f00f474b4.jpg",
              "99b.jpg": "embedded\u002F54b12658b9cd5635dd68a0a80cba44175472dfbd6c3a93f06a35ac875f353037.jpg",
              "91b.jpg": "embedded\u002F201b932c4b6282c18d44241dbfe43fa83a1543440527d633f8cdcfdd147eb615.jpg",
              "92a.jpg": "embedded\u002F6f975ec948f1040e934fcf5bbe267249b32b24d17db6538462be83c3ddb8d193.jpg",
              "92b.jpg": "embedded\u002Fb20e59de6cc6573d3b01e7566f3c8e82178c6f673e6fd98a3f2d4106a8910f2b.jpg",
              "94b.jpg": "embedded\u002Fa3718704c8749ada4155d6997907108e18f68ea909435033865cc6cd86106fa0.jpg",
              "95a.jpg": "embedded\u002Fd6683f1527ad34133abe922f41344d6e5c0ff9d3db8cb76dee26b0f55d9359de.jpg",
              "95b.jpg": "embedded\u002F4278f19008e725d7db6142b040cc93ffe52cd48793638792613a29461fd0c638.jpg",
              "83b.jpg": "embedded\u002Fe57d20baca9c1a30f6366e7cbeabc47283c3e9759b7960be625fb7d856a199b6.jpg",
              "87a.jpg": "embedded\u002F144841285192d9876edd57ce4e2412e5370b3a10c78d9235b8d7e5e8acbddaf7.jpg",
              "87b.jpg": "embedded\u002Ff558f7a5c760340b1ef61c605cc9c74f5be134fe78674e9e932466bb6146834c.jpg",
              "88a.jpg": "embedded\u002Fe036a396aa602741fe4057f8f68814a9781932d2fe3717f241ef5da0cb1eb326.jpg",
              "88b.jpg": "embedded\u002F3101e2a7567e88a0894d83b1fd0fb400f6f76ecce2612371f6f1964015a983d1.jpg",
              "89a.jpg": "embedded\u002Fd7e384ceaeb0341bc1d6b1b29f5a63c38f040e670b68e59d635264c6346f4ba5.jpg",
              "89b.jpg": "embedded\u002Fae9373f3a6e6a0db4049ffa83a8a3f0211a2e7fad1a7e146aa85f6a67d902276.jpg",
              "90a.jpg": "embedded\u002Ff8e96c18efc5ebf895373294122060decf3520179173362b597ed0d032fcb882.jpg",
              "90b.jpg": "embedded\u002Ff361ecc670b422b5d0f6d7751c750c99ad74198a524c463accf42af88c60f7c0.jpg",
              "91a.jpg": "embedded\u002F032c47b3baad163ab3e34b7551337f98e1d6a2b3f13f60bb7f173a36a825afe0.jpg",
              "81b.jpg": "embedded\u002F0d712dd613cfc80490711f20a65f3631fbd843b6bf495457cb3805c9ad298e7b.jpg",
              "82a.jpg": "embedded\u002F49b62c580d6058d127abf138f32cc9d285c1dbb2ff9918f2611d9b79c9396f8a.jpg",
              "82b.jpg": "embedded\u002F734dab6e44a9d664e825793b5956bc6e1f2ad16d0238f99a9d2b4c3401234b5e.jpg",
              "83a.jpg": "embedded\u002F94317c10c2f3937d80e8b5078067b7eda3e4363ff5e518d3cf4cddbacb49c091.jpg",
              "84a.jpg": "embedded\u002Fd449825f24f2ff137205d5c1dbbd218d5dca4b5f758ba6c13c7a5dae7fd08bbc.jpg",
              "84b.jpg": "embedded\u002F9a3b858e9cd8cadde1ad77f9dccbb5083aa904e27ec2be42a746f23a28970340.jpg",
              "85a.jpg": "embedded\u002F1e358c7cb0ee960dcd36e73225f2824f897633744c3bf3638140aac4dd45d01e.jpg",
              "85b.jpg": "embedded\u002Fbc7ffba03684f3a522e4e09caffeef4578dc77d6ea1e88848c984b7cffa6ca0d.jpg",
              "86a.jpg": "embedded\u002F5397d82663c46854ef110b13cfd712b78efbabef78dad43bc0cfb5cf31dec7f5.jpg",
              "86b.jpg": "embedded\u002F79035d4ced825e989cfb25813db379252de71136ebef5c5d608650b6fa5702c6.jpg",
              "77a.jpg": "embedded\u002Fe71b09de8a21851bd623c44b6b91a6cacff872d32197f786cb1f6dda645999c6.jpg",
              "77b.jpg": "embedded\u002F2bc322194fb475e0b1a9d094377e19b2d9d117ec80669d9e305ba7c90d8dc0a2.jpg",
              "78a.jpg": "embedded\u002F7c01eabb5599883493c1b47d34b9284e7a9bde126890d10bc8abf4b1eb1143bc.jpg",
              "78b.jpg": "embedded\u002F1e69c131480ea3ad38135e77e2862e0c9da62571f7bfc7ddac5a9374a1a06f79.jpg",
              "79a.jpg": "embedded\u002F8908ccda60a95d6b7d1ea52e50a875b4a22057dcd1007de202b1067afdbdebb8.jpg",
              "79b.jpg": "embedded\u002Fce9527ded1121add298e72857b63d2851dfdf963e31fa8e03156890abac77507.jpg",
              "80a.jpg": "embedded\u002F4a7bef7f37d4afaacde95a44ebd12564a31d4241cfc93f1b5d2a2786935e562f.jpg",
              "80b.jpg": "embedded\u002Fac44e2f44b72de34a2d6816fcb2bb4c0469cb3cb5c331a11a6280dd2e6cc55bd.jpg",
              "81a.jpg": "embedded\u002Fc5b8e05becab6bb12ddf24ca56d2936617b6e16d2086d1555e4e2299a267a8fe.jpg",
              "71a.jpg": "embedded\u002Fbf7bdcb961b8e6adb0a7691c4416c4011db9c26bc697f8cdb56d27ee896476f8.jpg",
              "71b.jpg": "embedded\u002F6a4dae583952f22555c701d2763c557f6b64f86d8b5275d315cc8922d2d63cd4.jpg",
              "72a.jpg": "embedded\u002Ffaa76474efd29122c5dde32d522fec2a7b199e8775d438118217c0d6931de635.jpg",
              "72b.jpg": "embedded\u002Fb02bde6b1a0d4a7dc1444a58521ff091eb333acd7a93bc7cc7e592f0e246eede.jpg",
              "73a.jpg": "embedded\u002Fe8aca2141e3548b4f70caef51baf51671955db8af48fdfb78d6fc32a79a15908.jpg",
              "73b.jpg": "embedded\u002F82059c128f7a4ae11157f320ef2d5a674ddd4c015d0670be562728999b878862.jpg",
              "74a.jpg": "embedded\u002F6f244faaafcdde0dce0b30b3ff29c09e86659e60ef548960e81e2d59830c47e4.jpg",
              "74b.jpg": "embedded\u002F4035278160613027c81b0f5ba5473d9fea179efa79c06cfac308dda0fabb6a4e.jpg",
              "75a.jpg": "embedded\u002Fdcdd8807c6088731fb506ebf9288833d849a512aff726dc4e2fd8eef1921eb4c.jpg",
              "75b.jpg": "embedded\u002F83b1b495175ba0d46578e169487c0ef51d9981fb07c9cc033af47a7b9b5b628e.jpg",
              "76a.jpg": "embedded\u002Ffb93a9867e43221636bb692e96f9ee0c8783a3ff279f62e8c0742a79139286f7.jpg",
              "76b.jpg": "embedded\u002Fd5dfc09396a5d56a5974647d3149ffab1c6b2a235e7694245cece22bd04787c9.jpg",
              "101b.jpg": "embedded\u002F410a98bf40a1c7e9922d4298014dc98819f4e9e24e5d9a55eb55d1e46c2df224.jpg",
              "102a.jpg": "embedded\u002Fb41d0418853893e19249a3e3b5beda11aa98b71c6c8512781b69e341204dba76.jpg",
              "102b.jpg": "embedded\u002F1d8a1d60aee74eed77f96467c31185b734413a0290588627432b0ff9fce4806c.jpg",
              "103a.jpg": "embedded\u002F062ef954e83a669323deefa16c29444605a2f8ba755e24e088c8d8901a548171.jpg",
              "103b.jpg": "embedded\u002F3cac238b501270b62f8e82f116db2fd6e211363ca8c674b09dbcc3a25ce75ce6.jpg",
              "104a.jpg": "embedded\u002F66b9201a030fdbd01ad93a2ced03f3b88203f2d5b312b38fa20afeaf50c98563.jpg",
              "104b.jpg": "embedded\u002F9c96cb2c0a5a70999c0e8d999b8ccd6e3c4fa8eb2300e0d95cdda2106d0eb342.jpg",
              "105a.jpg": "embedded\u002Fec770d3fa188f73a05f121c4b6c5da9343728a837e3b4c65988e602a98220b6b.jpg",
              "105b.jpg": "embedded\u002Ff2effa9f9e20d17f554a877a0f9de81d30dc00270e43024af88ff9f64fc990db.jpg",
              "100a.jpg": "embedded\u002Fe0191c5be0b791a16163d06631cb183dee82a1ac65293894823d8e81269cf106.jpg",
              "100b.jpg": "embedded\u002Ff1515aca03b964598d410d24cdd5a021f1b2384328ae29b2b4c68751574ed433.jpg",
              "101a.jpg": "embedded\u002F21ea4ed2fad595900c5ddd3d4c9e7634d5e69cb1fe6e58ece5e5fc2796a3fd02.jpg",
              "6a.jpg": "embedded\u002F307361b91818a3930d5d665bb1c1f0ecda01e41f6fd7ff43ba881f4550510189.jpg",
              "6b.jpg": "embedded\u002F76acc9ef36559c83e5fa8459ad2099406d10d9d7d0e8e62d8745c7dade3240c2.jpg",
              "7a.jpg": "embedded\u002F24d26b29e346072699b666243eb21d790a784a3daa111051794503dc4c80c9fc.jpg",
              "7b.jpg": "embedded\u002Fae55cebe61757e1fed62d635b1ba35cb800fe1f2d17999e48fd8c9f94cafc2b1.jpg",
              "8a.jpg": "embedded\u002F08c65ad52ecd235f517c83be67013c4bfc7bd083fe9289c2d3ca6cebdc55a2ed.jpg",
              "8b.jpg": "embedded\u002F4642a046e3d18a01e09d7b47deae3ad1bf2708b8076cf6ea72bb78641e5ca95e.jpg",
              "9a.jpg": "embedded\u002F9cb020191f70dc62ae4f8388f4d5960289ce30d534214649f2c28ad1a896f92a.jpg",
              "9b.jpg": "embedded\u002Fabaa6047f963657dec15dc122a317e43be0e91342df56d8fef53525508dbfc27.jpg",
              "69b.jpg": "embedded\u002F49537727a8a861872bb0625e6253eec46d43792b07ba9c0efd8e500b9636a73f.jpg",
              "70a.jpg": "embedded\u002Feb1d49cca13608a4f11236240732f26f2b7082e155a8209f04e7a36785d1c7a6.jpg",
              "70b.jpg": "embedded\u002F0696ba1526798f0375f3ed4b3bb20b699b6b285747b04a3d7ce6577358ef1d50.jpg",
              "61a.jpg": "embedded\u002Fb053347117017bc175ae3bfd5d8296f8f86b0eed127378b047355c5db67fa328.jpg",
              "64a.jpg": "embedded\u002Fa7f4cee8e20606f1ba04284afb9e383d932ee7cac02cc54c7e867c2289a0c3c5.jpg",
              "64b.jpg": "embedded\u002F6029698fc0022e12d8aecbc11b002796b1822579168a608a1f9b26266ee21a41.jpg",
              "65a.jpg": "embedded\u002Fc8427a2c3556e180f14d7c4232ad49f479e859aa52326bcc9a1e8d666ddc5c09.jpg",
              "65b.jpg": "embedded\u002F23e2dc129339fc8ca55d6d8b039d4d3ec44f3fa4534e1628b45a6e18cc58c4b8.jpg",
              "66a.jpg": "embedded\u002Fb49b98842fa4ee9efc18f4570d942f374310c3ca500431396b166fcf95f5db75.jpg",
              "66b.jpg": "embedded\u002F90aa87610068e796f17ded3a9033f5bcf37ca94b7257864bff1000b3eaffe69d.jpg",
              "67a.jpg": "embedded\u002F3c51514f31f59c80f7749789077b2440145a87e68c34f811c72f4ff817259229.jpg",
              "67b.jpg": "embedded\u002Fcbcca974e8bf611ffab16c857a8fd5078698aef2b3bb181ec98140be0931a909.jpg",
              "68a.jpg": "embedded\u002F4105b29555c9d2b086ecba73e6d4365780e21f35feeda5da3631acdeda8f85ca.jpg",
              "68b.jpg": "embedded\u002F5df078b3b48f256ad73a40f2297a389c39d7cd57904a246467d033d6b3cf551b.jpg",
              "69a.jpg": "embedded\u002F52fe303156f6ca7fbfb62edbea689ccf93b8f5e2881fe0acb2917e4d2b45f0f6.jpg",
              "5a.jpg": "embedded\u002Fc84c32ed2241c80634cc3a55cbb5259dec4d5acac87f33e047b3548c9cd7f426.jpg",
              "5b.jpg": "embedded\u002F2fd86f552f35de7fdafd5e0f426145d8df3a2fd5947bcb62247744cda36ed638.jpg",
              "59b.jpg": "embedded\u002F8412d64680a712f4392affc8f9015270ec2f6e0b257c6d2e18aadfe367f4f04a.jpg",
              "60a.jpg": "embedded\u002F31e5b49109aa9297815a826ff87e2a1fa07025162b67c70777bf377d385b1b13.jpg",
              "60b.jpg": "embedded\u002Ff13817b043e28c11a7029c1042448044688c4297d282386daf04c08bf923972a.jpg",
              "61b.jpg": "embedded\u002Fc52ddb7216854a649cfcaf52b4fe55fd56965dfd475cf87946fbab2c765bebee.jpg",
              "62a.jpg": "embedded\u002Fec87ca5f57c464cb8436e092df41752342e11ae9120968555302a17b72765360.jpg",
              "62b.jpg": "embedded\u002Fbd1c552d3041b9b7b5fcc4e25d89aea5e2a8eb6bfc2c3f040a2c94975a8ff1ab.jpg",
              "63a.jpg": "embedded\u002F929310f118a3641408685a993311000ab2cb7b614e0120f99fdc0ab1ace1a093.jpg",
              "63b.jpg": "embedded\u002F6ab1fb1f95db1a4befb7bb1e1773cf11971a0d6beea7adb372204a3e2a2495c7.jpg",
              "55a.jpg": "embedded\u002Fcf5ded7375b6087463c79b610f05a47038bfc67bd9f70d7f8ea68d5a06369464.jpg",
              "55b.jpg": "embedded\u002Fa08ecdf635d164373491f61f641139cb4f4cd7a95b553965c4901ad01013b695.jpg",
              "56a.jpg": "embedded\u002F2f2052ce44a1be84d49d89b0dcc23406c0790ff8158ee5c0dae8d1588705b836.jpg",
              "56b.jpg": "embedded\u002F3cf14b29c27519f58a08de872fa087d66761716fefb03f1e8cdbc73188c253ca.jpg",
              "57a.jpg": "embedded\u002Fc4c4432146f4ad85b003c08b8877da8b7da9f0197749df4dca9909322d6c3588.jpg",
              "57b.jpg": "embedded\u002Ff93d0a98def7debb10d4daf2a07d5fabdf610eba8594b415594f8674a73bebcd.jpg",
              "58a.jpg": "embedded\u002Fb6ec70005d2910a3e6f3ddbc3d6241c455da8d8c6d3880a949c00b4be48444cd.jpg",
              "58b.jpg": "embedded\u002Faed8bbd545acf6013ba36f8dbccc40af5265a75729435aa76bedae871da529fd.jpg",
              "59a.jpg": "embedded\u002F9361bbc1b037b753dd1be6f70781af1aa6440fa83fcf0c4d67c87c76fb5f765a.jpg",
              "50b.jpg": "embedded\u002Ffe1b977570da018787963087f7baf763b29a6842965109064068aca286706e07.jpg",
              "51a.jpg": "embedded\u002Fcf616a3a0410cf888ac7526fb6d5d4ab591485593a4d20aae628aa997612a1ee.jpg",
              "51b.jpg": "embedded\u002F198aafea57acb87c827cae5e29323c36ce1f3d5d2c042b3c4268b51a550ed522.jpg",
              "52a.jpg": "embedded\u002F69c4dcae4cc4c9870e672f60a248f4e16a415785f002a1804a6ce90a34429fd9.jpg",
              "52b.jpg": "embedded\u002F73d30127b516da3d1da2deaaca2bf14ca73e0e03c2f51719fafde46d4e58cb1f.jpg",
              "53a.jpg": "embedded\u002F3cdf04733c11d51635a384a2ae4ee19c4663e95a3a87f13c7c6b19f2a0801b95.jpg",
              "53b.jpg": "embedded\u002Fc2a7780bd2b33dc5c32e87a0e02a7166eefda71ffe1d5720dba8cfa47a963453.jpg",
              "54a.jpg": "embedded\u002F70ed008a752151378cd285319f361dcfc79319d9ceb2c301314547f1035f24c6.jpg",
              "54b.jpg": "embedded\u002F436e0f31b43c78bd366d2210bae8d12b9cb62c8eb4f309874c5a5e68db824de4.jpg",
              "4a.jpg": "embedded\u002Fa0d2b5073234d4134bbc00a108738bf837af3cc8f3a0f6477dc36b4845a0b6ad.jpg",
              "4b.jpg": "embedded\u002F322ecbd1a5726405a8e168254aa6a4df5719c9da41e3e87e11ba2535ae56805e.jpg",
              "47a.jpg": "embedded\u002Fc1ff6565d740a4ac6520fcf6a4b0817c202f3f08fe101eb431b5da99f3548948.jpg",
              "47b.jpg": "embedded\u002F694aabd9e0f521794b68f5e0d1bd10c1ec825678934a90e34b0365143b36da7d.jpg",
              "48a.jpg": "embedded\u002F1daea8f0c8d203d7b6104e8bdf7d72e4cfec7ff5aaad91b52cbdd8c1eab66735.jpg",
              "48b.jpg": "embedded\u002F1f891355d8ca7b2fb74f0e5b06dbfc9ea7822a91afa8ff7363ea49c37c6f9d6d.jpg",
              "49a.jpg": "embedded\u002F2b66d50f36539639aac62d36905413d8d9ee6ddc8ba915c9ce626deaa2b70582.jpg",
              "49b.jpg": "embedded\u002F2eff458cd2168152481f11647b4370f18ed10af5501d9c0be7242a2be580db97.jpg",
              "50a.jpg": "embedded\u002F3d113d40381df7c00f0c687490d49fa44438bdb30afe0d4351c94ef1008e687e.jpg",
              "44a.jpg": "embedded\u002F66f4d9e8063a969a345f33cb33977e93ec3a344d053c34083433316054d3d049.jpg",
              "44b.jpg": "embedded\u002F2d49feb5f46764d4ec9d81c826c35a6078f7a4286529559ab729056cea52c39d.jpg",
              "45a.jpg": "embedded\u002Fbe971f57e30078da566798b3dad694543670042d67e707bc0de2c68a43992f65.jpg",
              "45b.jpg": "embedded\u002Ffdc2a57d44213c98cb7d2114bb574de4e39162c88b4018557efdeeaea3eaaf8d.jpg",
              "46a.jpg": "embedded\u002F3119ddaf4702d44d8ee0c97d141e77b953fd27fcf6a59bc731e9be1097d976dd.jpg",
              "46b.jpg": "embedded\u002F06cff9b0327e6ead3aeb15d429aa8ae68f1bcd152c70cdae2aca1120d7f91018.jpg",
              "3a.jpg": "embedded\u002F671dacc8499b31e4524dca978cb7d882e0744fbbcf5a0060e125cd7e46e7f022.jpg",
              "3b.jpg": "embedded\u002F4cf46bd6ab9dca232307e348dcb0bc6d4d6b9e5078f80807018e8dd7b9466472.jpg",
              "40a.jpg": "embedded\u002Fb821c8de92e2238f958d7af50f2c2ee5022b0169089f56c1d52001c1c5ad7c2c.jpg",
              "40b.jpg": "embedded\u002Fc0cf61a9bf9aa28e45a5cb1c8990ad4ee3c0dc9cc0de62120c9efed5c29b3201.jpg",
              "41a.jpg": "embedded\u002F419d92d08ea374f28f897cd8dd6f9aeb79a94d306b2f6e6acf90347e9cd1e589.jpg",
              "41b.jpg": "embedded\u002F4cda2abaa9aae38d03104c44f95fc99244b7b5713eb0389556345cb3d1fe3fd9.jpg",
              "42a.jpg": "embedded\u002F475690cb3766d9e2d7ffbe05c97ca5a5582944f2a3a1911c4164fcbd16fed368.jpg",
              "42b.jpg": "embedded\u002F0cf1383fe842f3ba2e40a2f8066f27834f56dd14eddf7e654bc585f74286e3bb.jpg",
              "43a.jpg": "embedded\u002F6bb26fcfabb8e9e49047356bf267a47d3d3c0263834ebfa046f1c615d82c3626.jpg",
              "43b.jpg": "embedded\u002Ff8a67254e4f7b1473aa1de4aa749b164ab257e45be7a7bf7ce2dbd03a1aee15c.jpg",
              "31b.jpg": "embedded\u002F4832e3d6fff903c35df37ec3e3e260a617975ef1960b6461bf19b86da7cfa57b.jpg",
              "32a.jpg": "embedded\u002Fb45bfae45b40c7ed38b1d598097ab47e7aa70d1a9c323e779637832b17d4527d.jpg",
              "34b.jpg": "embedded\u002Ff0d23c5ecad8461f682cdeb1a899b52590e209c82f2e653d03a00ce81768d19d.jpg",
              "35a.jpg": "embedded\u002F875b97d703ddffe15b2947a3627be128d7814ffc1b9eb1fcf1f56024d7f23ce0.jpg",
              "35b.jpg": "embedded\u002F46f35f94afbf751395f7818a290310823df4f4645494ccd75087d22d81381739.jpg",
              "36a.jpg": "embedded\u002F2c9cc33f95cd6cd705de128b4eceef47881e477af9ab3a7f55e8bc59a03e3835.jpg",
              "36b.jpg": "embedded\u002F3530503d7bc2630f7fd631d00745cc9a7f8d6e94e30fb43819e25518f3ec698a.jpg",
              "37a.jpg": "embedded\u002F64b44abd77cfc023d123a09b29194c15e4a89c65ddb293f6c00d535b1147ec9e.jpg",
              "37b.jpg": "embedded\u002F1325c83e10231adf31376491e6745853c8ac845c3ee7ea7d7e22b7325bf78add.jpg",
              "38a.jpg": "embedded\u002F992bceff0687fe6caf3553cbe13fa5917e08ff7eda633b357aaaf0895ff8e4cf.jpg",
              "38b.jpg": "embedded\u002F62d76b2bb527a9b95fd9fe329c298422e1991470c90bc5d2ba195ad8dfe078b4.jpg",
              "39a.jpg": "embedded\u002F3dd2fbfb9fa5f02e4f09d03bf243f819774a1e9e00e39e0340f1d0f9f7ea6126.jpg",
              "39b.jpg": "embedded\u002F23888bce5be0a9772fc5ba9f1a35aec85e8e775bbd74e3e6977d35eb98d27eb0.jpg",
              "30b.jpg": "embedded\u002F8275e23516727f3f62d7d5e6807a16477f464e726a03c92a958cf4a9d0a4feb6.jpg",
              "31a.jpg": "embedded\u002F60138d95bc4472a3e34083a0fe15efa71efefe159d24d10c4a458f5b284ed165.jpg",
              "32b.jpg": "embedded\u002Fac335bbbdee458eedb9e291bebb14c79b8b3746316f8f067976cc8a98276dd43.jpg",
              "33a.jpg": "embedded\u002F136e1689d01634b001409ae680543a7b4c0af29ef4a82f623c10dd7d0983e17c.jpg",
              "33b.jpg": "embedded\u002F71da3e2e4948c4cb6e7a0dc8910bf316f195dab828511b37580bc99a6a4d2deb.jpg",
              "34a.jpg": "embedded\u002F9aefa35f66c7fef1ef81d5e0709bc9330f2a04a5a6d3328734c0a1802dd1ff4f.jpg",
              "2a.jpg": "embedded\u002F3da555a0d815725e71d82e9bd447f46e41192b0d610b19eef3960cf64b67fa3b.jpg",
              "2b.jpg": "embedded\u002F211d8af1b51e46dafedb3a63402175262e7183b1fce058ad42cbb49b6bffce7c.jpg",
              "26b.jpg": "embedded\u002Fdb796c1f96f26161b6ea6ed10d7bca18e30c27c4c4d93b0a14b1d0b4548866a8.jpg",
              "27a.jpg": "embedded\u002F236630eac5fbf4c1ebe1c3a7fe0366081e24092dd8804bd178243cbff9e38581.jpg",
              "27b.jpg": "embedded\u002Fd0af6af3e54b9ab4b48b6c1bdea44b87a464b6bb75d192881d2d410530fca42a.jpg",
              "28a.jpg": "embedded\u002Ff5cd7ba103f0ae18b3e43ed3fc08baa2610d474e0cc550648deeaff4b886b44c.jpg",
              "28b.jpg": "embedded\u002F8f62ab997fc70d089ecfa38e5c0600afe90fdde724e5b2c55807ef44dceb7b37.jpg",
              "29a.jpg": "embedded\u002Fc7df5e9782529cac80d8965959fa411547ac86acaaeca388bc3c856f36178d68.jpg",
              "29b.jpg": "embedded\u002Fdac5cece9a7ff24a46eeb52895a9f1a534b61e425f7a61a94c68d157bb3e8b09.jpg",
              "30a.jpg": "embedded\u002Fe751adf184cd5cd41e478ef505a7ddcaa5a776d5c91e90e8bf5a58064acd0362.jpg",
              "22b.jpg": "embedded\u002F2380ce0098c499c1726627923e7588f384d73f7914e0d0bbee062771a89ca4e0.jpg",
              "23a.jpg": "embedded\u002F0d82cf569a4acc3d501424321b5e8a590b91b6ca885dba12462f9fd3a0d56213.jpg",
              "23b.jpg": "embedded\u002Fb0aa18da30427cff3400a66ca5fc7bbb5f77637e1677be1f2da052fa5f25c9da.jpg",
              "24a.jpg": "embedded\u002F1b735824ec75ec7598d1eaa6197aada4e64771128fe7748d22a3df4c63155e9c.jpg",
              "24b.jpg": "embedded\u002Fe86a28829c424c1e92e54689a5d167707a86377f720d8d34a2b8140d85afb8f8.jpg",
              "25a.jpg": "embedded\u002Fdbf5d964da17f282c29c2d5a87d3bbf85eb1f3f0b87bdb3ff720a73457a5a217.jpg",
              "25b.jpg": "embedded\u002F474e35e69af74c6518c9db7ec22c78fccb582ef09f36d12abef5f844d1022947.jpg",
              "26a.jpg": "embedded\u002F9457890f41392bcf72fa706c5e72da81322f920a49fc921415677f104a1d6c0e.jpg",
              "1a.jpg": "embedded\u002F40ec0aeed5a00fd0f9b99f4b35a1aa7c29c8ff676f841814e890cb6514c7c939.jpg",
              "1b.jpg": "embedded\u002F0ccadce9c0f474d481f138ba342be1608522d7548d3407eed47139a6bf1bed76.jpg",
              "19a.jpg": "embedded\u002F1083bf3e7b667c7ea0fb84d39a3bb24a4faf2376f67aab219d9afaa136ee1899.jpg",
              "19b.jpg": "embedded\u002F4590fd824e6f975e96ed1362b1ee8142ebe281f1fc44aecf7345935ce7ce3bb6.jpg",
              "20a.jpg": "embedded\u002F58ef4883702d9a3f4913c8ae62cdfd7b146af3e5e9b78e354c6acb4225934e0a.jpg",
              "20b.jpg": "embedded\u002F38e0c5b07d737a31268cced522e9b04dada31cd5dd909a415fc30c2e0cc00d5b.jpg",
              "21a.jpg": "embedded\u002Fddac78ace94bd6222c5e34d6884dffb2f955adcb5c09bf19cc78c96fb10e2988.jpg",
              "21b.jpg": "embedded\u002Fc79a2f3334cf0be5fb78acdb9d109f1a6a7885460454cf065526ac3302c254b7.jpg",
              "22a.jpg": "embedded\u002F4fcb1eedb49dc9fb3cd31c4af6c44ba9409c02c2b40daec9d5f3021bcad37183.jpg",
              "14b.jpg": "embedded\u002F47a37415a436466d108eeec5cb5ee9f6925cef2d93f674b5ddbbf94f4c791635.jpg",
              "15a.jpg": "embedded\u002F0f7de3d6b4f616e41e63e05419b4866ca99d6e4bda8329a7a98b71e3be244ca2.jpg",
              "15b.jpg": "embedded\u002F38c62870b80bd5a68c821da1b2faf0898dfd793c6be99e69bc43580a2710c872.jpg",
              "16a.jpg": "embedded\u002F730c9d43ab6269c45b012c00fdf9c8236c69bcdac6506e320191bec0c2043902.jpg",
              "16b.jpg": "embedded\u002Fb35a04e8a2ea8785360700f55371ad6eec1a129f8b8173bb24f9809983a4d40d.jpg",
              "17a.jpg": "embedded\u002F1d7c4381c6f326c5f112618420853583e923988cd940ed73b997d719051339b0.jpg",
              "17b.jpg": "embedded\u002F46c23dcf5cb7001486dbc5a681af51abd0281634ac148aa9d67f92e14fcb6fe4.jpg",
              "18a.jpg": "embedded\u002Ff4fbf2921510640c6652f73a842476fcf98a83ab6e689e89a0c084f5586b0a67.jpg",
              "18b.jpg": "embedded\u002F4e120ca73c66b1f27bcb706d1039573e1860fc420ccab0528811bd181a1b5501.jpg",
              "10a.jpg": "embedded\u002F0ee328b416d9c5d1f8b4e19d75bc3b1b00f095378de2800da787501313ba5f17.jpg",
              "10b.jpg": "embedded\u002F0a85f4b434cc1dffe821f9e0519e659a035d9e6e6b73fd3cde3264983a7c86d9.jpg",
              "11a.jpg": "embedded\u002F09487ca861c9e8e0b46613104869b9d2376b1c77cb269cc7dbe6089e0a4a1f79.jpg",
              "11b.jpg": "embedded\u002F309beae8a6f4cf09ee779515b14a12e1f843ff060dca94c687c1e53216a184ee.jpg",
              "12a.jpg": "embedded\u002F85798de537a8035f97574a8d9ba2b806342b4daa98e75c62c1e39223b8b5fe68.jpg",
              "12b.jpg": "embedded\u002F6e34a055eb67e4d96c5524d3b163fe43df91f9970bbf5b69b7d2d5ce60b01f66.jpg",
              "13a.jpg": "embedded\u002F84075ce0f841293161268199ea2019ee2b87da422efc6c6fc47883bf3d020f77.jpg",
              "13b.jpg": "embedded\u002Fc361e96137bb62cb18d5d7f6cfaa10366d289eba79c5dc4862338e05c1095162.jpg",
              "14a.jpg": "embedded\u002Fd0a90b5a88ec7893581852dfa4833c7e08c43f4a83d4770ef710e5ec4f065ea2.jpg",
              "50.jpg": "embedded\u002F7bec58055225fbcfae6108db48b63321503d27b5412ad4b988ac3f8501da3034.jpg",
              "55.jpg": "embedded\u002F1ef0b17745c107edf7cdc61b433066e9c6a5a78e0ac1173b3bd015e55668a031.jpg",
              "-55.jpg": "embedded\u002Fff9eb65ffc9a5b6971b0219eca35d8ec3c02f4f6b839ff318b205ffefaf44971.jpg",
              "60.jpg": "embedded\u002Fa4f9b5791e6f8737917c824cf3601deca826e856775cb476e8649796823108e4.jpg",
              "-60.jpg": "embedded\u002F6613118dcfb0c2f900851dc7592de1a1e9ff469d02ba9ce688f7247ffdfe8a7f.jpg",
              "65.jpg": "embedded\u002F11d92667856cb8aa3fb11bda2b604e840cfdbb4ecb4eb047d7013e8b05b830b1.jpg",
              "-65.jpg": "embedded\u002F0ff90f2de67ed19bac59ba6e255252b8fa572ee01b4b0ef1fe96da8e789c230f.jpg",
              "70.jpg": "embedded\u002Fdadf552fb8a7b75a07cf9c8d459149658a399def6bb96c54a1780c8691b19f4b.jpg",
              "-70.jpg": "embedded\u002Fe5c911b41c3363470de96fe7f2b2fd4d1824441fb1a90b47bf7f6bd62fe5800d.jpg",
              "75.jpg": "embedded\u002Fe68cda0b913010ea24611cdfe46e021c169bf62364ba0593636c9b570c8e4e34.jpg",
              "-75.jpg": "embedded\u002F3ef5c50dfc24b0e4de0f1b015bbc1d5a1fbc626c615f67a20d57b0495a0c244e.jpg",
              "80.jpg": "embedded\u002Fd2fa78f1244f1f765bd499f84cc1e017862c66ae0ded563a89a810c298b883b4.jpg",
              "-80.jpg": "embedded\u002F22f11df15bf9c7a3da4a58e3d549bbc913178b42a675bf888773e16c5f2d87a3.jpg",
              "85.jpg": "embedded\u002F7d2c846994a477910223cfbb3f240f5c0e3a31e3871f84e69e66c9a618fac5f3.jpg",
              "-85.jpg": "embedded\u002Faee6b2801374ed2ad42c1c27920808144ec759ada464320fc9964d406c4e41b0.jpg",
              "90.jpg": "embedded\u002F1ac24a6af892fb393d2ac81c72dfc77dcb08c0af0385ea73684a631b6d9db9b6.jpg",
              "-90.jpg": "embedded\u002F324500f40b2063a0253e8e277130d7370a87f6046471e235a1b05286188ba7f4.jpg",
              "95.jpg": "embedded\u002Ffd810aa6c92de13739767374fc1e4658a26b2604660e45fd575d36dea34c6cc3.jpg",
              "-95.jpg": "embedded\u002Fada7f30136a6dd36450e706153f09761b0ac7e679ba0fccbb0f008071865e97f.jpg"
            },
            "responses": {
              "": ""
            },
            "parameters": {},
            "messageHandlers": {},
            "title": "final decision"
          },
          {
            "type": "lab.html.Page",
            "items": [
              {
                "type": "text",
                "content": "\u003Cp\u003EPlease rate your confidence:\u003C\u002Fp\u003E\n\u003Cp style=\"font-size: 0.9em; color: #555;\"\u003E\n  Use the slider below to indicate how confident you are in your final choice, where:\n  \u003Cbr\u003E\u003Cstrong\u003E50%\u003C\u002Fstrong\u003E means \"I'm just guessing\", and\n  \u003Cstrong\u003E100%\u003C\u002Fstrong\u003E means \"I'm completely certain.\"\n\u003C\u002Fp\u003E\n\n\u003Cdiv style=\"width: 60%; max-width: 400px;\"\u003E\n  \u003Cinput\n    type=\"range\"\n    id=\"Final_confidence_slider\"\n    name=\"Final_confidence\"\n    min=\"50\"\n    max=\"100\"\n    value=\"75\"\n    step=\"1\"\n    style=\"width: 100%;\"\n    oninput=\"document.getElementById('slider_value').textContent = this.value;\"\n    required\n  \u003E\n  \u003Cdiv style=\"display: flex; justify-content: space-between; font-size: 0.9em; margin-top: 0.25em;\"\u003E\n    \u003Cspan\u003E50%\u003C\u002Fspan\u003E\n    \u003Cspan\u003E100%\u003C\u002Fspan\u003E\n  \u003C\u002Fdiv\u003E\n  \u003Cp style=\"margin-top: 0.5em;\"\u003ESelected: \u003Cspan id=\"slider_value\"\u003E75\u003C\u002Fspan\u003E%\u003C\u002Fp\u003E\n\u003C\u002Fdiv\u003E\n\n",
                "title": "Final confidence"
              }
            ],
            "scrollTop": true,
            "submitButtonText": "Continue →",
            "submitButtonPosition": "right",
            "files": {},
            "responses": {
              "": ""
            },
            "parameters": {},
            "messageHandlers": {},
            "title": "Final confidence"
          },
          {
            "type": "lab.canvas.Screen",
            "content": [],
            "viewport": [
              800,
              600
            ],
            "files": {},
            "responses": {
              "": ""
            },
            "parameters": {},
            "messageHandlers": {},
            "title": "Inter trial interval",
            "timeout": "500"
          }
        ]
      }
    },
    {
      "type": "lab.html.Screen",
      "files": {},
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Thank you",
      "content": "\u003Cheader class=\"content-vertical-center content-horizontal-center\"\u003E\n  \u003Ch1\u003EThank you for your participation!\u003C\u002Fh1\u003E\n\u003C\u002Fheader\u003E\n\n\u003Cmain\u003E\n  \u003Cp\u003E\n    We appreciate your time and effort in completing this study.\n  \u003C\u002Fp\u003E\n\n\u003Cp\u003E \n  We would like to inform you that the AI advice and its confidence levels shown during the task were \u003Cstrong\u003Epreprogrammed\u003C\u002Fstrong\u003E and did not come from a real AI system. The values were based on a previous study and were selected to reflect the average performance observed in that study.\n  \u003Cbr\u003E\n  \n  \u003Cfooter class=\"content-vertical-center content-horizontal-center\"\u003E\n  \u003Cp\u003EYou can call the researcher now. \u003Cstrong\u003EDo not yet close this window\u003C\u002Fstrong\u003E\u003C\u002Fp\u003E\n\u003C\u002Ffooter\u003E\n",
      "timeout": "1000"
    },
    {
      "type": "lab.flow.Sequence",
      "files": {},
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "AI literacy",
      "content": [
        {
          "type": "lab.html.Page",
          "items": [
            {
              "required": true,
              "type": "html",
              "content": "\u003Csection\u003E\r\n      \u003Ch2\u003EQuiz\u003C\u002Fh2\u003E\r\n      \u003Cp\u003ENow you are asked to complete a quiz. \u003C\u002Fp\u003E\r\n      \u003Cp\u003EThe quiz includes 8 multiple-choice questions.\u003C\u002Fp\u003E\r\n      \u003Cp\u003EEach question will have 4 answer options and an additional \"I don't know\" option.\u003C\u002Fp\u003E\r\n      \u003Cp\u003EClick continue to start the quiz!\u003C\u002Fp\u003E\r\n    \u003C\u002Fsection\u003E\r\n",
              "name": ""
            }
          ],
          "scrollTop": true,
          "submitButtonText": "Continue →",
          "submitButtonPosition": "right",
          "files": {},
          "responses": {
            "": ""
          },
          "parameters": {},
          "messageHandlers": {},
          "title": "quiz introduction"
        },
        {
          "type": "lab.html.Page",
          "items": [
            {
              "required": true,
              "type": "radio",
              "shuffle": true,
              "label": "AI was first mentioned in… ",
              "options": [
                {
                  "label": "…the 1950s.",
                  "coding": "1"
                },
                {
                  "label": "…the 2000s.",
                  "coding": "-1"
                },
                {
                  "label": "…the 1880s.",
                  "coding": "-1"
                },
                {
                  "label": "…the 1980s. ",
                  "coding": "-1"
                },
                {
                  "label": "I don't know.",
                  "coding": "0"
                }
              ],
              "name": "socio1"
            }
          ],
          "scrollTop": true,
          "submitButtonText": "Continue →",
          "submitButtonPosition": "right",
          "files": {},
          "responses": {
            "": ""
          },
          "parameters": {},
          "messageHandlers": {},
          "title": "quiz 1"
        },
        {
          "type": "lab.html.Page",
          "items": [
            {
              "required": true,
              "type": "radio",
              "shuffle": true,
              "label": "How are human and artificial  intelligence related? ",
              "options": [
                {
                  "label": "They are different, each has its own strengths and weaknesses.",
                  "coding": "1"
                },
                {
                  "label": "Their strengths and weaknesses converge. ",
                  "coding": "-1"
                },
                {
                  "label": "They predict each other.",
                  "coding": "-1"
                },
                {
                  "label": "They are  the same, concerning strengths and weaknesses. ",
                  "coding": "-1"
                },
                {
                  "label": "I don't know",
                  "coding": "0"
                }
              ],
              "name": "socio2"
            }
          ],
          "scrollTop": true,
          "submitButtonText": "Continue →",
          "submitButtonPosition": "right",
          "files": {},
          "responses": {
            "": ""
          },
          "parameters": {},
          "messageHandlers": {},
          "title": "quiz 2"
        },
        {
          "type": "lab.html.Page",
          "items": [
            {
              "required": true,
              "type": "radio",
              "label": "AI research... ",
              "options": [
                {
                  "label": "…happens in an interdisciplinary field including multiple technologies.",
                  "coding": "1"
                },
                {
                  "label": "...is only fiction at this point in time. ",
                  "coding": "-1"
                },
                {
                  "label": "…revolves predominantly around  optimization.",
                  "coding": "-1"
                },
                {
                  "label": "...refers to one specific AI technology. ",
                  "coding": "-1"
                },
                {
                  "label": "I don't know.",
                  "coding": "0"
                }
              ],
              "shuffle": true,
              "name": "socio3"
            }
          ],
          "scrollTop": true,
          "submitButtonText": "Continue →",
          "submitButtonPosition": "right",
          "files": {},
          "responses": {
            "": ""
          },
          "parameters": {},
          "messageHandlers": {},
          "title": "quiz 3"
        },
        {
          "type": "lab.html.Page",
          "items": [
            {
              "required": true,
              "type": "radio",
              "label": "What is a possible risk for  humans of AI technology?",
              "shuffle": true,
              "name": "socio4",
              "options": [
                {
                  "label": "Deep fakes render videos unattributable. ",
                  "coding": "1"
                },
                {
                  "label": "Digital assistants take over  self-driving cars. ",
                  "coding": "-1"
                },
                {
                  "label": "Image generators break the rules of art.",
                  "coding": "-1"
                },
                {
                  "label": "Voice  generators make people unlearn natural languages. ",
                  "coding": "-1"
                },
                {
                  "label": "I don't know. ",
                  "coding": "0"
                }
              ]
            }
          ],
          "scrollTop": true,
          "submitButtonText": "Continue →",
          "submitButtonPosition": "right",
          "files": {},
          "responses": {
            "": ""
          },
          "parameters": {},
          "messageHandlers": {},
          "title": "quiz 4"
        },
        {
          "type": "lab.html.Page",
          "items": [
            {
              "required": true,
              "type": "radio",
              "label": "What is the central distinction between supervised and unsupervised learning?",
              "options": [
                {
                  "label": "Supervised learning uses labeled datasets.",
                  "coding": "1"
                },
                {
                  "label": "Unsupervised learning  may happen anytime.",
                  "coding": "-1"
                },
                {
                  "label": "Supervised learning is performed by supervised  personnel. ",
                  "coding": "-1"
                },
                {
                  "label": "Supervised learning supersedes unsupervised learning. ",
                  "coding": "-1"
                },
                {
                  "label": "I don't know",
                  "coding": "0"
                }
              ],
              "shuffle": true,
              "name": "tech1"
            }
          ],
          "scrollTop": true,
          "submitButtonText": "Continue →",
          "submitButtonPosition": "right",
          "files": {},
          "responses": {
            "": ""
          },
          "parameters": {},
          "messageHandlers": {},
          "title": "quiz 5"
        },
        {
          "type": "lab.html.Page",
          "items": [
            {
              "required": true,
              "type": "radio",
              "label": "Which of the following statements is true? ",
              "options": [
                {
                  "label": "ML is a part of AI",
                  "coding": "1"
                },
                {
                  "label": "ML and AI are mutually exclusive",
                  "coding": "-1"
                },
                {
                  "label": "AI is a part of  ML ",
                  "coding": "-1"
                },
                {
                  "label": "AI and ML are the same ",
                  "coding": "-1"
                },
                {
                  "label": "I don't know.",
                  "coding": "0"
                }
              ],
              "shuffle": true,
              "name": "tech2"
            }
          ],
          "scrollTop": true,
          "submitButtonText": "Continue →",
          "submitButtonPosition": "right",
          "files": {},
          "responses": {
            "": ""
          },
          "parameters": {},
          "messageHandlers": {},
          "title": "quiz 6"
        },
        {
          "type": "lab.html.Page",
          "items": [
            {
              "required": true,
              "type": "radio",
              "label": "What is a typical application of an AI at which it is usually better than non-AI?  ",
              "options": [
                {
                  "label": "Image recognition",
                  "coding": "1"
                },
                {
                  "label": "Creating annual reports ",
                  "coding": "-1"
                },
                {
                  "label": "Undefined processes",
                  "coding": "-1"
                },
                {
                  "label": "Hardware space analysis  ",
                  "coding": "-1"
                },
                {
                  "label": "I don't know",
                  "coding": "0"
                }
              ],
              "shuffle": true,
              "name": "tech3"
            }
          ],
          "scrollTop": true,
          "submitButtonText": "Continue →",
          "submitButtonPosition": "right",
          "files": {},
          "responses": {
            "": ""
          },
          "parameters": {},
          "messageHandlers": {},
          "title": "quiz 7"
        },
        {
          "type": "lab.html.Page",
          "items": [
            {
              "required": true,
              "type": "radio",
              "label": "Running the same request with the same data on the same AI… ",
              "options": [
                {
                  "label": "…could give different results.",
                  "coding": "1"
                },
                {
                  "label": "…increase the computing speed.",
                  "coding": "-1"
                },
                {
                  "label": "…never give different results. ",
                  "coding": "-1"
                },
                {
                  "label": "…double the computing time. ",
                  "coding": "-1"
                },
                {
                  "label": "I don't know",
                  "coding": "0"
                }
              ],
              "shuffle": true,
              "name": "tech4"
            }
          ],
          "scrollTop": true,
          "submitButtonText": "Continue →",
          "submitButtonPosition": "right",
          "files": {},
          "responses": {
            "": ""
          },
          "parameters": {},
          "messageHandlers": {},
          "title": "quiz 8"
        },
        {
          "type": "lab.html.Page",
          "items": [
            {
              "required": true,
              "type": "html",
              "content": "\u003Ch2\u003EQuiz Completed!\u003C\u002Fh2\u003E\r\n\u003Cp\u003ENow let's move on to the Face-Matching task!\u003C\u002Fp\u003E\r\n",
              "name": ""
            }
          ],
          "scrollTop": true,
          "submitButtonText": "Continue →",
          "submitButtonPosition": "right",
          "files": {},
          "responses": {
            "": ""
          },
          "parameters": {},
          "messageHandlers": {},
          "title": "quiz finished"
        }
      ]
    }
  ]
})

// Let's go!
study.run()